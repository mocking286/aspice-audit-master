/* AuditFlow UI language layer.
 *
 * Application data remains unchanged.  This layer translates rendered UI
 * strings only, so changing language never mutates projects, evidence, or
 * assessment records saved in the workspace.
 */
(function () {
  "use strict";

  const CJK = /[\u3400-\u9fff\uf900-\ufaff]/;
  const CJK_RUN = /[\u3400-\u9fff\uf900-\ufaff]+/g;
  const textSource = new WeakMap();
  const attributeSource = new WeakMap();
  const controlSource = new WeakMap();
  const protectedControls = new Set();
  const attributes = ["aria-label", "placeholder", "title", "alt"];
  let language = "zh-CN";
  let observer = null;
  let scheduled = false;
  let originalTitle = document.title;

  const exact = new Map(Object.entries({
    "审核总览": "Audit overview",
    "ASPICE 评估": "ASPICE assessment",
    "自定义审核": "Custom audits",
    "更多": "More",
    "设置": "Settings",
    "工作台": "Workspace",
    "本地评估": "Local evaluation",
    "AI 就绪": "AI ready",
    "AI 分析中": "AI analysing",
    "后端就绪": "AI service ready",
    "后端离线": "Local evaluation",
    "后端已连接": "AI service connected",
    "重新检查": "Refresh status",
    "关闭": "Close",
    "通知": "Notifications",
    "展开导航": "Expand navigation",
    "搜索项目、证据、过程和评估师记录": "Search projects, evidence, processes and assessor records",
    "实时掌握审核状态、证据链和关闭风险": "See audit status, evidence chains and closure risk in real time",
    "新建 ASPICE 评估": "New ASPICE assessment",
    "进入审核项目": "Open audit project",
    "进行中的审核": "Active audits",
    "本地解析覆盖": "Local parsing coverage",
    "待人工复核": "Awaiting human review",
    "当前阻塞项": "Current blockers",
    "审核 Workflow 实时漏斗": "Live audit workflow",
    "上传证据包": "Upload evidence package",
    "本地解析与映射": "Local parsing and mapping",
    "全过程 AI 复核": "Full AI review",
    "SUP 闭环检查": "SUP closure check",
    "依赖与影响分析": "Dependency and impact analysis",
    "评估师确认与导出": "Assessor confirmation and export",
    "账户与角色": "Account and roles",
    "AI / MCP": "AI / MCP",
    "Helix 表格解析": "Helix table parsing",
    "数据与隐私": "Data and privacy",
    "个人资料": "Profile",
    "评估角色与权限": "Assessment roles and permissions",
    "本地后端配置": "Local AI service configuration",
    "后端状态": "AI service status",
    "启用后端 AI 引擎": "Enable local AI service",
    "后端地址": "AI service URL",
    "保存配置": "Save configuration",
    "检查解析器": "Check parser",
    "保存设置": "Save settings",
    "导出备份": "Export backup",
    "评估护栏": "Assessment guardrails",
    "本地规则": "Local rules",
    "AI 评估已完成": "AI assessment completed",
    "已切换本地评估": "Switched to local assessment",
    "新建自定义审核方案": "New custom audit scheme",
    "发起自定义审核": "Start custom audit",
    "返回项目": "Back to project",
    "返回总览": "Back to overview",
    "未找到该内容": "Content not found",
    "目标可能已被删除或链接已失效。": "The target may have been deleted or the link has expired.",
    "取消": "Cancel",
    "创建项目": "Create project",
    "创建方案": "Create scheme",
    "创建任务": "Create audit",
    "保存资料": "Save profile",
    "导出 Word": "Export Word",
    "导出 PDF": "Export PDF",
    "当前版本": "Current version",
    "历史版本": "Version history",
    "证据": "Evidence",
    "版本": "Versions",
    "关闭与报告": "Close and report",
    "执行": "Conduct",
    "计划": "Plan",
    "日程": "Schedule",
    "追溯": "Traceability",
    "合并": "Consolidate",
    "草稿": "Draft",
    "待评估": "Ready",
    "AI 评估中": "AI assessment running",
    "待复核": "Awaiting review",
    "已完成": "Completed",
    "已归档": "Archived",
    "已关闭": "Closed",
    "未连接": "Not connected",
    "就绪": "Ready",
    "无": "None",
    "是": "Yes",
    "否": "No",
    "今天": "Today",
    "昨天": "Yesterday",
    "天前": "days ago"
  }));

  const phrases = Object.entries({
    "Automotive SPICE 内审工作台": "Automotive SPICE audit workspace",
    "实时数据": "Live data",
    "审核状态": "audit status",
    "证据链": "evidence chain",
    "关闭风险": "closure risk",
    "本地解析": "local parsing",
    "人工复核": "human review",
    "人工确认": "human confirmation",
    "评估师": "assessor",
    "审核项目": "audit project",
    "审核方案": "audit scheme",
    "审核任务": "audit task",
    "审核问题": "audit question",
    "审核模型": "audit model",
    "审核范围": "assessment scope",
    "审核结果": "assessment result",
    "评估结果": "assessment result",
    "评估报告": "assessment report",
    "评估项目": "assessment project",
    "评估记录": "assessment record",
    "评估目的": "assessment purpose",
    "评估类别": "assessment class",
    "评估方式": "assessment method",
    "评估状态": "assessment status",
    "评估师记录": "assessor record",
    "证据包": "evidence package",
    "证据引用": "evidence references",
    "证据不足": "insufficient evidence",
    "证据充分性": "evidence sufficiency",
    "证据对象": "evidence object",
    "工作产品": "work product",
    "项目名称": "project name",
    "产品 / 项目": "product / project",
    "受评组织": "assessed organisation",
    "受审对象": "audited organisation",
    "审核负责人": "audit owner",
    "目标能力等级": "target capability level",
    "当前审核状态": "current audit status",
    "人工最终评分": "human final rating",
    "AI 候选": "AI candidate",
    "AI 把握度": "AI confidence",
    "AI 专业评分理由": "AI assessment rationale",
    "人工复核意见": "human review notes",
    "弱项": "weakness",
    "优势": "strength",
    "建议": "recommendation",
    "观察": "observation",
    "备注": "comment",
    "访谈问题": "interview question",
    "已保存": "saved",
    "保存": "save",
    "删除": "delete",
    "编辑": "edit",
    "查看": "view",
    "进入": "open",
    "新建": "new",
    "导入": "import",
    "导出": "export",
    "添加": "add",
    "清除": "clear",
    "重置": "reset",
    "确认": "confirm",
    "返回": "back",
    "状态": "status",
    "版本": "version",
    "日期": "date",
    "名称": "name",
    "类型": "type",
    "内容": "content",
    "范围": "scope",
    "用户": "user",
    "角色": "role",
    "密码": "password",
    "项目": "project",
    "文件": "file",
    "表格": "table",
    "本地": "local",
    "已连接": "connected",
    "离线": "offline",
    "失败": "failed",
    "成功": "successful",
    "处理中": "processing",
    "等待": "waiting",
    "进行中": "in progress",
    "已选择": "selected",
    "条": " items",
    "个": "",
    "项": " items",
    "份": " files",
    "行": " rows",
    "表": " tables",
    "需": "requires ",
    "未": "not ",
    "已": "",
    "和": " and ",
    "与": " and ",
    "或": " or "
  }).sort((a, b) => b[0].length - a[0].length);

  function fallback(chunk) {
    if (/证据|文件|文档|表格|资料/.test(chunk)) return "evidence detail";
    if (/项目|产品|组织|团队/.test(chunk)) return "project detail";
    if (/评估|审核|评分|过程|能力/.test(chunk)) return "assessment detail";
    if (/风险|问题|弱项|建议|整改/.test(chunk)) return "finding detail";
    if (/设置|配置|账户|权限/.test(chunk)) return "configuration detail";
    if (/保存|删除|创建|导入|导出|返回|关闭/.test(chunk)) return "action";
    return "assessment content";
  }

  function translate(value) {
    const source = String(value == null ? "" : value);
    if (!CJK.test(source)) return source;
    const leading = source.match(/^\s*/)?.[0] || "";
    const trailing = source.match(/\s*$/)?.[0] || "";
    const core = source.slice(leading.length, source.length - trailing.length);
    if (exact.has(core)) return leading + exact.get(core) + trailing;
    let output = core;
    for (const [from, to] of phrases) output = output.split(from).join(to);
    output = output.replace(CJK_RUN, fallback);
    output = output.replace(/，/g, ", ").replace(/。/g, ". ").replace(/；/g, "; ").replace(/：/g, ": ").replace(/！/g, "!").replace(/？/g, "?").replace(/（/g, "(").replace(/）/g, ")").replace(/【/g, "[").replace(/】/g, "]").replace(/、/g, ", ");
    output = output.replace(/\s{2,}/g, " ").replace(/\s+([,.;:!?])/g, "$1").trim();
    if (!/[A-Za-z0-9]/.test(output)) output = "assessment content";
    return leading + output + trailing;
  }

  function editableControls(root) {
    if (!root) return [];
    const selector = "input, textarea";
    const candidates = root.matches?.(selector) ? [root, ...(root.querySelectorAll?.(selector) || [])] : [...(root.querySelectorAll?.(selector) || [])];
    return candidates.filter(element => {
      if (element.closest?.("script, style, [data-i18n-skip]")) return false;
      if (element.tagName === "TEXTAREA") return true;
      const type = String(element.getAttribute("type") || "text").toLowerCase();
      return !["hidden", "password", "file", "checkbox", "radio", "color", "range", "button", "submit", "reset", "image"].includes(type);
    });
  }

  function restoreControls(root = document.body) {
    const candidates = new Set([...editableControls(root), ...protectedControls]);
    candidates.forEach(element => {
      const source = controlSource.get(element);
      if (!source) return;
      element.value = source.value;
      element.readOnly = source.readOnly;
      if (source.title == null) element.removeAttribute("title");
      else element.setAttribute("title", source.title);
      element.removeAttribute("data-i18n-protected-value");
      controlSource.delete(element);
      protectedControls.delete(element);
    });
  }

  function translateControls(root = document.body) {
    if (language !== "en") return;
    [...protectedControls].forEach(element => {
      if (!element.isConnected) {
        controlSource.delete(element);
        protectedControls.delete(element);
      }
    });
    editableControls(root).forEach(element => {
      const existing = controlSource.get(element);
      const original = existing?.value ?? element.value;
      if (!CJK.test(original || "")) return;
      const source = existing || { value: original, readOnly: element.readOnly, title: element.getAttribute("title") };
      source.translated = translate(source.value);
      controlSource.set(element, source);
      protectedControls.add(element);
      element.value = source.translated;
      element.readOnly = true;
      element.setAttribute("data-i18n-protected-value", "true");
      element.setAttribute("title", "Original Chinese data is protected. Switch to Chinese to view or edit it.");
    });
  }

  function temporarilyRestoreControls() {
    if (language !== "en" || !protectedControls.size) return;
    restoreControls(document.body);
    queueMicrotask(() => {
      if (language === "en") translateControls(document.body);
    });
  }

  function restoreTree(root) {
    if (!root) return;
    restoreControls(root);
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(node => {
      if (textSource.has(node)) node.nodeValue = textSource.get(node);
    });
    const elements = root.querySelectorAll ? [root, ...root.querySelectorAll("*")] : [];
    elements.forEach(element => {
      const values = attributeSource.get(element);
      if (values) Object.entries(values).forEach(([name, value]) => element.setAttribute(name, value));
    });
  }

  function translateTree(root = document.body) {
    if (language !== "en" || !root) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const parent = node.parentElement;
        if (!parent || parent.closest("script, style, textarea, [data-i18n-skip]")) return NodeFilter.FILTER_REJECT;
        return CJK.test(node.nodeValue || "") ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(node => {
      if (!textSource.has(node)) textSource.set(node, node.nodeValue);
      node.nodeValue = translate(textSource.get(node));
    });
    const elements = root.querySelectorAll ? [root, ...root.querySelectorAll("*")] : [];
    elements.forEach(element => {
      if (element.closest("script, style, [data-i18n-skip]")) return;
      attributes.forEach(name => {
        const value = element.getAttribute?.(name);
        if (!value || !CJK.test(value)) return;
        const known = attributeSource.get(element) || {};
        if (!(name in known)) {
          known[name] = value;
          attributeSource.set(element, known);
        }
        element.setAttribute(name, translate(known[name]));
      });
    });
    if (CJK.test(document.title)) {
      if (!originalTitle) originalTitle = document.title;
      document.title = translate(originalTitle);
    }
    translateControls(root);
  }

  function scheduleTranslation() {
    if (language !== "en" || scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      translateTree(document.body);
    });
  }

  function setLanguage(next) {
    language = next === "en" ? "en" : "zh-CN";
    document.documentElement.lang = language === "en" ? "en" : "zh-CN";
    if (language === "en") translateTree(document.body);
    else {
      restoreTree(document.body);
      document.title = originalTitle;
    }
  }

  function start() {
    if (observer || !document.body) return;
    observer = new MutationObserver(scheduleTranslation);
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    document.addEventListener("click", temporarilyRestoreControls, true);
    document.addEventListener("submit", temporarilyRestoreControls, true);
  }

  window.AuditFlowI18n = {
    start,
    setLanguage,
    translateTree,
    isEnglish: () => language === "en",
    translate,
    untranslatedVisibleTextCount() {
      const text = document.body?.innerText || "";
      const textCount = (text.match(CJK) || []).length;
      const controlCount = editableControls(document.body).reduce((count, element) => count + ((String(element.value || "").match(CJK) || []).length), 0);
      return textCount + controlCount;
    }
  };
}());
