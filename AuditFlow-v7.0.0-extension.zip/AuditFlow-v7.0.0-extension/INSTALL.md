# Install AuditFlow v7.0 in Microsoft Edge

## 1. 加载扩展

1. 打开 edge://extensions。
2. 开启开发人员模式。
3. 如需保留旧版工作区，请先在旧扩展中导出备份；移除扩展会清除该扩展的本地浏览器数据。
4. 解压 `AuditFlow-v7.0.0-extension.zip`，选择“加载解压缩的扩展”，并选择解压后的 `AuditFlow-v7.0.0-extension` 文件夹。
5. 固定 AuditFlow 图标。

## 2. 使用工具栏弹窗

- 点击浏览器工具栏中的 AuditFlow 图标。
- 弹窗会列出正在进行的审核项目，并显示 AI 服务和 Helix Bridge 的就绪状态。
- 选择项目可直接打开相应审核；选择进入首页可打开工作台总览。

## 3. 复核 BP / GP AI 初稿

1. 进入 ASPICE 项目并运行“AI 预评估”或打开左侧“AI 评审”。
2. 在“评定结果（BP + GP · AI 初稿，可复核改定）”按过程、指标或复核状态筛选。
3. 用评分下拉快速改定；需要补充理由、证据引用或 O/W/R 时点击“核对详情”。
4. Codex 参考评审仅使用已定稿记录，并另存版本；结果必须由评估师复核。

## 4. 配置 Codex AI 复核（可选）

1. 在工作台右上角进入设置。
2. 打开 AI 与本地解析设置，再选择 Codex / Virtual Key。
3. 使用 Virtual Keys 链接进入组织门户；AuditFlow 只检查本机 Codex 或 VS Code 相关配置是否存在，不读取配置文件、登录令牌或密钥。
4. 输入 Virtual Key 并保存。该 Key 仅保存在本机 AI 服务进程内存中，浏览器存储、扩展压缩包和日志均不会保留它。
5. AI 服务未就绪时，AuditFlow 自动使用本地规则评估；这不会阻塞文件解析、人工审核或项目操作。

## 5. 语言与夜间模式

- 右上角月亮/太阳按钮切换白天和 GitHub Dark 夜间模式。
- 紧邻的 EN / ZH 按钮切换中文和英文。英文模式会将界面、可见评估内容和模型输出统一为英文。

## 本地数据

- 项目与评估元数据：扩展 localStorage。
- 记录附件 Blob：IndexedDB。
- 报告与备份：本机受控输出目录（仅在 AI 服务可用时生成）。
- Helix Bridge：仍可使用 helix-bridge.ps1 或 start-helix-bridge.cmd；其状态独立于 AI 服务。
