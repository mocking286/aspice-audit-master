// AuditFlow v7.0 optional local AI service.
// It stays separate from the extension UI and is used only for model review
// and service-side report generation. The extension always retains its local
// professional-rule workflow when this optional service is unavailable.
// Browser extension responsibilities are limited to UI/DOM element operations.
// All LLM evaluation/opinion calls and visual report generation run here on
// the user's computer via the command line.

import http from "node:http";
import { spawn, spawnSync } from "node:child_process";
import { readFile, stat } from "node:fs/promises";
import { existsSync, readdirSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  VERSION,
  ENGINE_NAME,
  loadAIConfig,
  evaluateProject,
  buildVisualReport,
  buildWordReport,
  buildRecordsCsv,
  buildProjectListCsv,
  buildElementsCsv,
  buildCustomAuditCsv,
  buildOpinionPrompt,
  ensureOutputDir,
  writeOutput,
  reportMeta,
  callProvider,
  extractOutputText
} from "./engine.mjs";

const currentDir = path.dirname(fileURLToPath(import.meta.url));
const applicationRoot = currentDir;
const config = loadAIConfig(path.join(currentDir, "backend-config.json"));
const CODEX_VIRTUAL_KEY_PORTAL = "https://llmcost.johnsonelectric.com/";
const CODEX_DEFAULT_API_BASE_URL = "https://llmcost.johnsonelectric.com/v1";
const runtimeCodex = { virtualKey: "", baseUrl: "", model: "", useLocalConfig: true };
const CODEX_CLI_STATUS_TTL_MS = 30_000;
const CODEX_CLI_REQUEST_TIMEOUT_MS = 60_000;
const CODEX_CLI_MAX_OUTPUT_BYTES = 1_000_000;
const codexCliState = { checkedAt: 0, available: false, authenticated: false };
const port = Number(process.env.AUDITFLOW_PORT || config.port || 4173);
const outputDir = path.isAbsolute(config.outputDir || "output")
  ? config.outputDir
  : path.join(currentDir, config.outputDir || "output");
const reportsDir = path.join(outputDir, "reports");
const exportsDir = path.join(outputDir, "exports");
ensureOutputDir(reportsDir);
ensureOutputDir(exportsDir);

function safeProviderUrl(value) {
  try {
    const parsed = new URL(String(value || ""));
    const localHttp = parsed.protocol === "http:" && ["127.0.0.1", "localhost", "::1"].includes(parsed.hostname);
    if (parsed.protocol !== "https:" && !localHttp) return "";
    return parsed.toString().replace(/\/$/, "");
  } catch (_) {
    return "";
  }
}

function localCodexCliStatus({ force = false } = {}) {
  const now = Date.now();
  if (!force && now - codexCliState.checkedAt < CODEX_CLI_STATUS_TTL_MS) return { ...codexCliState };
  // `login status` only returns an exit status here.  Its text is deliberately
  // discarded so account identity, login details, and credentials stay local.
  try {
    const result = spawnSync("codex", ["login", "status"], {
      cwd: applicationRoot,
      shell: false,
      stdio: "ignore",
      timeout: 4_000,
      windowsHide: true
    });
    codexCliState.available = !result.error && !result.signal;
    codexCliState.authenticated = codexCliState.available && result.status === 0;
  } catch (_) {
    codexCliState.available = false;
    codexCliState.authenticated = false;
  }
  codexCliState.checkedAt = now;
  return { ...codexCliState };
}

function nestedCodexText(value, depth = 0) {
  if (depth > 5 || value == null) return "";
  if (typeof value === "string") return value;
  if (Array.isArray(value)) return value.map(item => nestedCodexText(item, depth + 1)).filter(Boolean).join("\n");
  if (typeof value !== "object") return "";
  for (const key of ["text", "content", "message", "output", "result"]) {
    const text = nestedCodexText(value[key], depth + 1);
    if (text) return text;
  }
  return "";
}

function parseCodexCliOutput(rawOutput) {
  const messages = [];
  String(rawOutput || "").split(/\r?\n/).forEach(line => {
    const source = line.trim();
    if (!source) return;
    try {
      const event = JSON.parse(source);
      const item = event?.item || event?.message || {};
      const text = nestedCodexText(item) || nestedCodexText(event?.text) || nestedCodexText(event?.output);
      if ((item?.type === "agent_message" || event?.type === "agent_message" || event?.type === "item.completed") && text) messages.push(text);
    } catch (_) {
      // Older Codex CLI versions can emit only the final response on stdout.
      if (!source.startsWith("{") && !source.startsWith("[")) messages.push(source);
    }
  });
  return messages.join("\n").trim();
}

function runLocalCodexCli(prompt, timeoutMs = CODEX_CLI_REQUEST_TIMEOUT_MS, model = "") {
  const status = localCodexCliStatus();
  if (!status.authenticated) return Promise.resolve({ ok: false, error: "The local Codex session is not ready" });
  const boundedPrompt = String(prompt || "").slice(0, 180_000);
  const bridgePrompt = [
    "You are the local AuditFlow model bridge for an Automotive SPICE assessment.",
    "Return only the requested assessor opinion. Do not run commands, read local files, change data, reveal credentials, or describe tool use.",
    "Use only the assessment context supplied below. Keep the response concise, actionable, and auditable.",
    "",
    boundedPrompt
  ].join("\n");
  return new Promise(resolve => {
    let stdout = "";
    let settled = false;
    let timedOut = false;
    let timer = null;
    const finish = result => {
      if (settled) return;
      settled = true;
      if (timer) clearTimeout(timer);
      resolve(result);
    };
    let child;
    try {
      // All command-line arguments are fixed. The assessment prompt travels on
      // stdin, never on the command line, to avoid exposing project context.
      const safeModel = /^[A-Za-z0-9._:-]{1,120}$/.test(String(model || "")) ? String(model) : "";
      const args = ["exec", "--ephemeral", "--skip-git-repo-check", "--ignore-rules", "--color", "never", "--json", "-s", "read-only"];
      if (safeModel) args.push("-m", safeModel);
      args.push("-");
      child = spawn("codex", args, {
        cwd: applicationRoot,
        shell: false,
        stdio: ["pipe", "pipe", "ignore"],
        windowsHide: true
      });
    } catch (_) {
      finish({ ok: false, error: "The local Codex model could not be started" });
      return;
    }
    timer = setTimeout(() => {
      timedOut = true;
      child.kill();
    }, Math.max(5_000, Math.min(Number(timeoutMs) || CODEX_CLI_REQUEST_TIMEOUT_MS, CODEX_CLI_REQUEST_TIMEOUT_MS)));
    child.on("error", () => finish({ ok: false, error: "The local Codex model could not be started" }));
    child.stdout.on("data", chunk => {
      if (settled) return;
      stdout += chunk.toString("utf8");
      if (Buffer.byteLength(stdout, "utf8") > CODEX_CLI_MAX_OUTPUT_BYTES) {
        child.kill();
        finish({ ok: false, error: "The local Codex response exceeded the safety limit" });
      }
    });
    child.on("close", code => {
      if (settled) return;
      if (timedOut) return finish({ ok: false, error: "The local Codex model request timed out" });
      const output = parseCodexCliOutput(stdout);
      if (code === 0 && output) return finish({ ok: true, output, transport: "codex-cli" });
      finish({ ok: false, error: "The local Codex model returned no usable assessment" });
    });
    child.stdin.on("error", () => {});
    child.stdin.end(bridgePrompt, "utf8");
  });
}

function readLocalCodexSummary() {
  // This is an existence-only check.  It never opens VS Code or Codex
  // configuration files, so local tokens and other settings stay private.
  const home = process.env.USERPROFILE || process.env.HOME || "";
  const appData = process.env.APPDATA || "";
  const candidates = [
    { kind: "codex", file: path.join(home, ".codex", "config.toml") },
    { kind: "vscode", file: path.join(appData, "Code", "User", "settings.json") },
    { kind: "vscode", file: path.join(appData, "Code - Insiders", "User", "settings.json") },
    { kind: "vscode", file: path.join(home, ".vscode", "settings.json") }
  ];
  const summary = { detected: false, codexConfigDetected: false, vscodeCodexDetected: false, vscodeSettingsDetected: false, provider: "", model: "", baseUrl: "", requiresOpenAiAuth: false };
  for (const candidate of candidates) {
    if (!candidate.file || !existsSync(candidate.file)) continue;
    if (candidate.kind === "codex") summary.codexConfigDetected = true;
    else summary.vscodeSettingsDetected = true;
  }
  for (const extensionRoot of [path.join(home, ".vscode", "extensions"), path.join(home, ".cursor", "extensions")]) {
    try {
      if (existsSync(extensionRoot) && readdirSync(extensionRoot).some(name => /codex|openai/i.test(name))) summary.vscodeCodexDetected = true;
    } catch (_) { /* a missing or inaccessible editor directory is not an error */ }
  }
  summary.detected = summary.codexConfigDetected || summary.vscodeCodexDetected;
  return summary;
}

function activeAiConfig(overrides = {}) {
  const detected = readLocalCodexSummary();
  const cli = localCodexCliStatus();
  const localBaseUrl = runtimeCodex.useLocalConfig ? detected.baseUrl : "";
  const baseUrl = safeProviderUrl(overrides.baseUrl || runtimeCodex.baseUrl || localBaseUrl || config.baseUrl || CODEX_DEFAULT_API_BASE_URL) || CODEX_DEFAULT_API_BASE_URL;
  const model = String(overrides.model || runtimeCodex.model || (runtimeCodex.useLocalConfig ? detected.model : "") || config.model || "gpt-5.4");
  return {
    ...config,
    ...overrides,
    enabled: runtimeCodex.virtualKey ? true : config.enabled,
    mode: "provider",
    baseUrl,
    model,
    apiKey: runtimeCodex.virtualKey || config.apiKey || "",
    cli
  };
}

async function requestModelOpinion(ai, prompt, timeoutMs = 45_000) {
  // An explicit in-session Virtual Key opts into the HTTP provider. Otherwise
  // prefer the authenticated local Codex session, even if the parent process
  // happens to inherit an ambient API key from the user's shell.
  if (!runtimeCodex.virtualKey && ai.cli?.authenticated) return runLocalCodexCli(prompt, timeoutMs, ai.model);
  if (ai.apiKey) {
    const providerResult = await callProvider(ai, { model: ai.model, input: prompt, store: false }, timeoutMs);
    if (!providerResult.ok) return { ok: false, error: providerResult.payload?.error?.message || `Provider returned ${providerResult.status}` };
    const output = extractOutputText(providerResult.payload);
    return output ? { ok: true, output, transport: "provider" } : { ok: false, error: "Provider returned no text output" };
  }
  if (ai.cli?.authenticated) return runLocalCodexCli(prompt, timeoutMs, ai.model);
  return { ok: false, error: "No local model session is available" };
}

function codexStatusPayload() {
  const detected = readLocalCodexSummary();
  const active = activeAiConfig();
  const cliPreferred = !runtimeCodex.virtualKey && active.cli.authenticated;
  return {
    ok: true,
    portalUrl: CODEX_VIRTUAL_KEY_PORTAL,
    detected: {
      configured: detected.detected,
      codexConfig: detected.codexConfigDetected,
      vscodeCodex: detected.vscodeCodexDetected,
      cliAvailable: active.cli.available,
      cliAuthenticated: active.cli.authenticated,
      provider: detected.provider || null,
      model: detected.model || null,
      apiEndpointDetected: !!detected.baseUrl,
      requiresOpenAiAuth: detected.requiresOpenAiAuth
    },
    session: {
      virtualKeyConfigured: !!runtimeCodex.virtualKey,
      model: active.model,
      providerReady: !!active.apiKey || active.cli.authenticated,
      transport: cliPreferred ? "codex-cli" : active.apiKey ? "provider" : "unavailable",
      usesDetectedConfig: !!runtimeCodex.useLocalConfig
    }
  };
}

function requestCanConfigureLocalCredentials(request) {
  const origin = String(request.headers.origin || "");
  return origin.startsWith("chrome-extension://") || origin.startsWith("http://127.0.0.1") || origin.startsWith("http://localhost");
}

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".htm": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".doc": "application/msword; charset=utf-8",
  ".csv": "text/csv; charset=utf-8",
  ".txt": "text/plain; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".ico": "image/x-icon"
};

function corsHeaders() {
  return {
    "access-control-allow-origin": "*",
    "access-control-allow-headers": "content-type, authorization",
    "access-control-allow-methods": "GET, POST, OPTIONS",
    "access-control-expose-headers": "content-disposition"
  };
}

function sendJson(response, status, value) {
  response.writeHead(status, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...corsHeaders() });
  response.end(JSON.stringify(value));
}

function sendText(response, status, text, contentType = "text/plain; charset=utf-8") {
  response.writeHead(status, { "content-type": contentType, "cache-control": "no-store", ...corsHeaders() });
  response.end(text);
}

function sendFile(response, filePath, downloadName = null) {
  const headers = {
    "content-type": mimeTypes[path.extname(filePath).toLowerCase()] || "application/octet-stream",
    "cache-control": "no-store",
    ...corsHeaders()
  };
  if (downloadName) headers["content-disposition"] = `attachment; filename="${encodeURIComponent(downloadName)}"`;
  const body = readFile(filePath);
  body.then(buffer => {
    response.writeHead(200, headers);
    response.end(buffer);
  }).catch(error => {
    response.writeHead(error.code === "ENOENT" ? 404 : 500, { "content-type": "text/plain; charset=utf-8", ...corsHeaders() });
    response.end(error.code === "ENOENT" ? "Not found" : "Internal server error");
  });
}

function resolveRequestPath(requestUrl) {
  const pathname = decodeURIComponent(new URL(requestUrl, `http://127.0.0.1:${port}`).pathname);
  if (pathname === "/") return path.join(applicationRoot, "index.html");
  const candidate = path.resolve(applicationRoot, `.${pathname}`);
  return candidate.startsWith(applicationRoot + path.sep) ? candidate : null;
}

async function readJsonBody(request) {
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 8_000_000) throw new Error("Request body too large");
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}");
}

function healthPayload() {
  const active = activeAiConfig();
  const cliPreferred = !runtimeCodex.virtualKey && active.cli.authenticated;
  const credentialSource = runtimeCodex.virtualKey
    ? "virtual-key-session"
    : cliPreferred
      ? "codex-cli-session"
    : active.apiKey
      ? "local-credential"
      : "not-configured";
  return {
    status: "ok",
    app: "AuditFlow AI",
    version: VERSION,
    engine: ENGINE_NAME,
    backend: "node-command-line",
    ai: {
      enabled: active.enabled,
      mode: active.mode,
      model: active.model,
      baseUrl: active.baseUrl,
      apiKeySet: !!active.apiKey,
      credentialSource,
      transport: cliPreferred ? "codex-cli" : active.apiKey ? "provider" : "unavailable"
    },
    codex: codexStatusPayload(),
    output: { reports: reportsDir, exports: exportsDir },
    time: new Date().toISOString()
  };
}

function makeDownloadUrl(filename) {
  return `/api/output/reports/${encodeURIComponent(filename)}`;
}

async function handleGenerateReport(request, response, body) {
  const project = body.project;
  if (!project || !project.id) throw new Error("Missing project");
  const format = String(body.format || "html");
  const type = String(body.type || "standard");
  let content = "";
  let filename = "";
  let contentType = "";
  if (format === "html") {
    filename = reportMeta(project, "visual-report", "html").filename;
    content = buildVisualReport(project, type);
    contentType = "text/html; charset=utf-8";
  } else if (format === "word" || format === "doc") {
    filename = reportMeta(project, "assessment-report", "doc").filename;
    content = buildWordReport(project, type);
    contentType = "application/msword; charset=utf-8";
  } else if (format === "records-csv") {
    filename = reportMeta(project, "records", "csv").filename;
    content = buildRecordsCsv(project);
    contentType = "text/csv; charset=utf-8";
  } else if (format === "projects-csv") {
    filename = reportMeta(project, "project-list", "csv").filename;
    content = buildProjectListCsv(body.projects || [project]);
    contentType = "text/csv; charset=utf-8";
  } else if (format === "elements-csv") {
    filename = reportMeta(project, "elements", "csv").filename;
    content = buildElementsCsv();
    contentType = "text/csv; charset=utf-8";
  } else if (format === "custom-csv") {
    filename = reportMeta(project, "custom-audit", "csv").filename;
    content = buildCustomAuditCsv(project);
    contentType = "text/csv; charset=utf-8";
  } else if (format === "json") {
    filename = reportMeta(project, "workspace-project", "json").filename;
    content = JSON.stringify(project, null, 2);
    contentType = "application/json; charset=utf-8";
  } else {
    throw new Error(`Unsupported report format: ${format}`);
  }
  const filePath = writeOutput(reportsDir, filename, content);
  const size = Buffer.byteLength(content, "utf8");
  sendJson(response, 200, {
    ok: true,
    format,
    filename,
    name: filename,
    size,
    path: filePath,
    url: makeDownloadUrl(filename),
    message: `报告已由后端引擎生成：${filePath}`
  });
}

const server = http.createServer(async (request, response) => {
  const url = request.url || "/";
  if (request.method === "OPTIONS") {
    response.writeHead(204, corsHeaders());
    response.end();
    return;
  }

  if (request.method === "GET" && (url === "/health" || url === "/api/health")) {
    sendJson(response, 200, healthPayload());
    return;
  }

  if (request.method === "GET" && url === "/api/codex/status") {
    sendJson(response, 200, codexStatusPayload());
    return;
  }

  if (url.startsWith("/api/output/")) {
    const rel = decodeURIComponent(url.slice("/api/output/".length));
    const candidate = path.resolve(outputDir, rel);
    if (!candidate.startsWith(outputDir + path.sep)) {
      sendText(response, 403, "Forbidden");
      return;
    }
    try {
      const info = await stat(candidate);
      if (!info.isFile()) throw Object.assign(new Error("Not found"), { code: "ENOENT" });
      sendFile(response, candidate, path.basename(candidate));
    } catch (error) {
      sendText(response, error.code === "ENOENT" ? 404 : 500, error.code === "ENOENT" ? "Not found" : "Internal server error");
    }
    return;
  }

  if (request.method === "POST") {
    try {
      const body = await readJsonBody(request);

      if (url === "/api/codex/virtual-key") {
        if (!requestCanConfigureLocalCredentials(request)) {
          sendJson(response, 403, { error: "Credential configuration is allowed only from a local AuditFlow page" });
          return;
        }
        const virtualKey = String(body.virtualKey || "").trim();
        if (virtualKey.length < 8 || virtualKey.length > 1024) throw new Error("Enter a valid Virtual Key");
        const requestedBaseUrl = safeProviderUrl(body.baseUrl) || CODEX_DEFAULT_API_BASE_URL;
        const detected = readLocalCodexSummary();
        runtimeCodex.virtualKey = virtualKey;
        runtimeCodex.useLocalConfig = body.useLocalConfig !== false;
        runtimeCodex.baseUrl = runtimeCodex.useLocalConfig && detected.baseUrl ? "" : requestedBaseUrl;
        runtimeCodex.model = String(body.model || "").trim().slice(0, 160);
        sendJson(response, 200, codexStatusPayload());
        return;
      }

      if (url === "/api/codex/clear-virtual-key") {
        if (!requestCanConfigureLocalCredentials(request)) {
          sendJson(response, 403, { error: "Credential configuration is allowed only from a local AuditFlow page" });
          return;
        }
        runtimeCodex.virtualKey = "";
        runtimeCodex.model = "";
        runtimeCodex.baseUrl = "";
        sendJson(response, 200, codexStatusPayload());
        return;
      }

      if (url === "/api/ai/opinion") {
        if (!body.prompt) throw new Error("Missing prompt");
        const ai = activeAiConfig(body.model ? { model: body.model } : {});
        const modelResult = await requestModelOpinion(ai, body.prompt, 60_000);
        if (!modelResult.ok) throw new Error(modelResult.error || "Model review is unavailable");
        sendJson(response, 200, { output: modelResult.output, transport: modelResult.transport });
        return;
      }

      if (url === "/api/ai/assess-indicators") {
        if (!Array.isArray(body.indicators) || !body.indicators.length) throw new Error("Missing indicators");
        if (body.indicators.length > 8) throw new Error("A maximum of 8 indicators is allowed per batch");
        const ai = activeAiConfig(body.model ? { model: body.model } : {});
        const prompt = body.prompt || "";
        const requestBody = body.requestBody || (prompt ? { model: ai.model, input: prompt, store: false } : null);
        if (!requestBody) throw new Error("Missing prompt or requestBody");
        let providerResult = await callProvider(ai, requestBody);
        if (!providerResult.ok) {
          providerResult = await callProvider(ai, { model: ai.model, input: `${prompt}\n\n只返回符合指定结构的 JSON 对象，不要 Markdown。`, store: false });
        }
        if (!providerResult.ok) throw new Error(providerResult.payload?.error?.message || `Provider returned ${providerResult.status}`);
        const output = extractOutputText(providerResult.payload);
        if (!output) throw new Error("Provider returned no output");
        let parsed;
        try {
          parsed = JSON.parse(String(output).trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, ""));
        } catch (_) {
          const start = output.indexOf("{");
          const end = output.lastIndexOf("}");
          parsed = JSON.parse(output.slice(start, end + 1));
        }
        if (!Array.isArray(parsed.assessments)) throw new Error("Provider JSON does not include assessments");
        sendJson(response, 200, { assessments: parsed.assessments });
        return;
      }

      if (url === "/api/engine/evaluate") {
        if (!body.project) throw new Error("Missing project");
        const result = await evaluateProject(body.project, String(body.type || "standard"), body.scheme || null, activeAiConfig(), body.options || {});
        sendJson(response, 200, result);
        return;
      }

      if (url === "/api/report/generate") {
        await handleGenerateReport(request, response, body);
        return;
      }

      if (url === "/api/export/workspace") {
        if (!body.workspace) throw new Error("Missing workspace");
        const stamp = new Date().toISOString().slice(0, 10);
        const filename = `auditflow-workspace-${stamp}.json`;
        const filePath = writeOutput(exportsDir, filename, JSON.stringify(body.workspace, null, 2));
        sendJson(response, 200, {
          ok: true,
          filename,
          size: Buffer.byteLength(JSON.stringify(body.workspace), "utf8"),
          path: filePath,
          url: `/api/output/exports/${encodeURIComponent(filename)}`,
          message: `工作区备份已由后端保存：${filePath}`
        });
        return;
      }
    } catch (error) {
      sendJson(response, 502, { error: error.name === "AbortError" ? "Model request timed out" : error.message });
      return;
    }
  }

  let target = resolveRequestPath(url);
  if (!target) {
    sendText(response, 403, "Forbidden");
    return;
  }
  try {
    const info = await stat(target);
    if (info.isDirectory()) target = path.join(target, "index.html");
    const body = await readFile(target);
    response.writeHead(200, {
      "content-type": mimeTypes[path.extname(target).toLowerCase()] || "application/octet-stream",
      "cache-control": "no-store",
      ...corsHeaders()
    });
    response.end(body);
  } catch (error) {
    sendText(response, error.code === "ENOENT" ? 404 : 500, error.code === "ENOENT" ? "Not found" : "Internal server error");
  }
});

// ---------------------------------------------------------------------------
// CLI entry points
// ---------------------------------------------------------------------------
function parseArgs(argv) {
  const args = {};
  for (let index = 0; index < argv.length; index++) {
    const arg = argv[index];
    if (arg.startsWith("--")) {
      const key = arg.slice(2);
      const value = argv[index + 1];
      args[key] = value !== undefined && !value.startsWith("--") ? value : true;
      if (value !== undefined && !value.startsWith("--")) index++;
    } else {
      (args._ ||= []).push(arg);
    }
  }
  return args;
}

async function cliMain(argv) {
  const args = parseArgs(argv);
  const command = args._?.[0] || "serve";
  const readJson = async filePath => JSON.parse(await readFile(path.resolve(filePath), "utf8"));

  if (command === "serve" || command === "server" || command === "start") {
    server.listen(port, "127.0.0.1", () => {
      console.log(`AuditFlow v${VERSION} backend running at http://127.0.0.1:${port}/`);
      console.log(`Reports output: ${reportsDir}`);
      console.log(`AI: ${config.enabled ? `${config.mode} · model ${config.model}` : "disabled"} (backend-config.json)`);
      console.log("Press Ctrl+C to stop.");
    });
    return;
  }

  if (command === "health") {
    console.log(JSON.stringify(healthPayload(), null, 2));
    return;
  }

  if (command === "evaluate") {
if (!args.project) throw new Error("Missing project input for evaluation");
    const project = await readJson(args.project);
    const scheme = args.scheme ? await readJson(args.scheme) : null;
    const result = await evaluateProject(project, String(args.type || "standard"), scheme, config);
    const out = args.out ? path.resolve(args.out) : null;
    if (out) {
      writeOutput(path.dirname(out), path.basename(out), JSON.stringify(result, null, 2));
      console.log(`Evaluated ${result.project.assessments.length} indicators; LLM used: ${result.llm.used}; result written to ${out}`);
    } else {
      console.log(JSON.stringify(result, null, 2));
    }
    return;
  }

  if (command === "opinion") {
if (!args.project) throw new Error("Missing project input for opinion generation");
    const raw = await readJson(args.project);
    const project = raw.project || raw;
    const prompt = buildOpinionPrompt(project, args.type || "standard");
    const providerResult = await callProvider(config, { model: config.model, input: prompt, store: false }, 45000);
    if (!providerResult.ok) throw new Error(providerResult.payload?.error?.message || `Provider returned ${providerResult.status}`);
    const output = extractOutputText(providerResult.payload);
    if (args.out) {
      writeOutput(path.dirname(path.resolve(args.out)), path.basename(args.out), output);
      console.log(`Opinion written to ${args.out}`);
    } else {
      console.log(output);
    }
    return;
  }

  if (command === "report") {
if (!args.project || !args.format) throw new Error("Missing project input or report format");
    const raw = await readJson(args.project);
    const project = raw.project || raw;
    const type = String(args.type || "standard");
    const format = String(args.format);
    let content = "";
    let filename = "";
    if (format === "html") { filename = reportMeta(project, "visual-report", "html").filename; content = buildVisualReport(project, type); }
    else if (format === "word" || format === "doc") { filename = reportMeta(project, "assessment-report", "doc").filename; content = buildWordReport(project, type); }
    else if (format === "records-csv") { filename = reportMeta(project, "records", "csv").filename; content = buildRecordsCsv(project); }
    else if (format === "elements-csv") { filename = reportMeta(project, "elements", "csv").filename; content = buildElementsCsv(); }
    else if (format === "projects-csv") { filename = reportMeta(project, "project-list", "csv").filename; content = buildProjectListCsv(project ? [project] : []); }
    else if (format === "custom-csv") { filename = reportMeta(project, "custom-audit", "csv").filename; content = buildCustomAuditCsv(project); }
    else if (format === "json") { filename = reportMeta(project, "workspace-project", "json").filename; content = JSON.stringify(project, null, 2); }
    else throw new Error(`Unsupported format: ${format}`);
    const target = args.out ? path.resolve(args.out) : path.join(reportsDir, filename);
    writeOutput(path.dirname(target), path.basename(target), content);
    console.log(`Report generated: ${target} (${Buffer.byteLength(content, "utf8")} bytes)`);
    return;
  }

  if (command === "export") {
if (!args.workspace) throw new Error("Missing workspace input for export");
    const workspace = await readJson(args.workspace);
    const filename = args.out ? path.basename(args.out) : `auditflow-workspace-${new Date().toISOString().slice(0, 10)}.json`;
    const target = args.out ? path.resolve(args.out) : path.join(exportsDir, filename);
    writeOutput(path.dirname(target), path.basename(target), JSON.stringify(workspace, null, 2));
    console.log(`Workspace backup written to ${target}`);
    return;
  }

  throw new Error(`Unknown command: ${command}. Expected: serve | health | evaluate | opinion | report | export`);
}

const isCli = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isCli && process.argv.slice(2).length > 0) {
  cliMain(process.argv.slice(2)).catch(error => {
    console.error(`AuditFlow CLI error: ${error.message}`);
    process.exit(1);
  });
} else {
  server.listen(port, "127.0.0.1", () => {
    console.log(`AuditFlow v${VERSION} backend running at http://127.0.0.1:${port}/`);
    console.log(`Reports output: ${reportsDir}`);
    console.log(`AI: ${config.enabled ? `${config.mode} · model ${config.model}` : "disabled"} (backend-config.json)`);
    console.log("Press Ctrl+C to stop.");
  });
}
