/* AuditFlow v7.0 backend client.
 * The browser extension ONLY performs UI/DOM element operations through this
 * client. All LLM evaluation/opinion calls and visual report generation are
 * executed by the optional local AI service.  When it is unavailable, the
 * browser keeps the audit workflow responsive with its local rule fallback.
 */
(function () {
  "use strict";

  const DEFAULT_BASE_URL = "http://127.0.0.1:4173";

  async function request(url, options = {}, timeoutMs = 120000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(url, { ...options, signal: controller.signal });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        const message = payload?.error || payload?.message || `后端返回 ${response.status}`;
        throw new Error(message);
      }
      return payload;
    } catch (error) {
      if (error.name === "AbortError") throw new Error("后端请求超时");
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }

  const AuditFlowBackend = {
    baseUrl: DEFAULT_BASE_URL,
    isOnline: false,
    healthInfo: null,
    lastCheckedAt: 0,

    setBaseUrl(value) {
      this.baseUrl = String(value || DEFAULT_BASE_URL).replace(/\/+$/, "") || DEFAULT_BASE_URL;
    },

    async health(timeoutMs = 2500) {
      const payload = await request(`${this.baseUrl}/api/health`, { method: "GET" }, timeoutMs);
      this.isOnline = payload?.status === "ok";
      this.healthInfo = payload;
      this.lastCheckedAt = Date.now();
      return payload;
    },

    async evaluate(project, type = "standard", scheme = null, options = {}) {
      const payload = await request(`${this.baseUrl}/api/engine/evaluate`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ project, type, scheme, options })
      }, 240000);
      this.isOnline = true;
      return payload;
    },

    async codexStatus() {
      const payload = await request(`${this.baseUrl}/api/codex/status`, { method: "GET" }, 5000);
      this.isOnline = true;
      return payload;
    },

    async configureCodexVirtualKey(settings) {
      const payload = await request(`${this.baseUrl}/api/codex/virtual-key`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(settings || {})
      }, 15000);
      this.isOnline = true;
      return payload;
    },

    async clearCodexVirtualKey() {
      const payload = await request(`${this.baseUrl}/api/codex/clear-virtual-key`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: "{}"
      }, 10000);
      this.isOnline = true;
      return payload;
    },

    async opinion(prompt, options = {}) {
      const payload = await request(`${this.baseUrl}/api/ai/opinion`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ prompt, ...(options || {}) })
      }, 60000);
      this.isOnline = true;
      return payload;
    },

    async assessIndicators(requestBody) {
      const payload = await request(`${this.baseUrl}/api/ai/assess-indicators`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(requestBody)
      }, 120000);
      this.isOnline = true;
      return payload;
    },

    async generateReport(project, format = "html", type = "standard", extra = {}) {
      const payload = await request(`${this.baseUrl}/api/report/generate`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ project, format, type, ...extra })
      }, 120000);
      this.isOnline = true;
      return payload;
    },

    async exportWorkspace(workspace) {
      const payload = await request(`${this.baseUrl}/api/export/workspace`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ workspace })
      }, 30000);
      this.isOnline = true;
      return payload;
    },

    async downloadFromUrl(url, fallbackName = "auditflow-download") {
      const response = await fetch(new URL(url, this.baseUrl).toString());
      if (!response.ok) throw new Error(`下载失败：${response.status}`);
      const blob = await response.blob();
      const objectUrl = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = objectUrl;
      anchor.download = fallbackName || "auditflow-download";
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
    },

    async ensureOnline() {
      if (this.isOnline && Date.now() - this.lastCheckedAt < 30000) return true;
      try {
        await this.health();
        return this.isOnline;
      } catch (_) {
        this.isOnline = false;
        return false;
      }
    }
  };

  // Read a previously saved backend URL (if any) before the app initializes.
  try {
    const stored = JSON.parse(localStorage.getItem("auditflow-ai-workspace-v1") || "null");
    if (stored?.settings?.backendUrl) AuditFlowBackend.setBaseUrl(stored.settings.backendUrl);
  } catch (_) { /* keep default */ }

  window.AuditFlowBackend = AuditFlowBackend;
})();
