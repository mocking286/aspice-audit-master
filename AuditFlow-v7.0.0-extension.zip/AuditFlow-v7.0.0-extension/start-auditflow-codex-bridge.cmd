@echo off
setlocal
set "BRIDGE_ROOT=%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%BRIDGE_ROOT%auditflow-codex-bridge.ps1"
endlocal
