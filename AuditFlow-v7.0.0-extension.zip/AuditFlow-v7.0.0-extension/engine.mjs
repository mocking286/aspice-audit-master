// AuditFlow v5.5 backend engine
// Pure Node.js implementation (no DOM, no browser APIs, no external binaries).
// Responsibilities:
//   1. Local professional rule engine (BP/GP candidate ratings, evidence chains)
//   2. LLM evaluation & opinion calls (OpenAI Responses-compatible HTTP API)
//   3. Visual report generation (Word-compatible HTML .doc, standalone HTML,
//      CSV, JSON) -- all saved/returned by the local backend process.

import { readFileSync, existsSync, mkdirSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

export const VERSION = "7.0.0";
export const ENGINE_NAME = "AuditFlow Backend Engine";

const currentDir = path.dirname(fileURLToPath(import.meta.url));

// ---------------------------------------------------------------------------
// Rule engine constants (kept identical to the v5.4 in-browser rule engine)
// ---------------------------------------------------------------------------
export const RATING_SCORE = { "N": 7.5, "P-": 23.75, "P": 32.5, "P+": 41.25, "L-": 58.75, "L": 67.5, "L+": 76.25, "F": 92.5 };
export const RATING_ORDER = ["N", "P-", "P", "P+", "L-", "L", "L+", "F"];
export const STATUS_LABEL = { draft: "草稿", ready: "待评估", running: "AI 评估中", review: "待复核", complete: "已完成", archived: "已归档" };

export const PROCESS_CATALOG = [
  ["ACQ.4", "供应商监控", "Supplier Monitoring", "ACQ", 7],
  ["SPL.2", "产品发布", "Product Release", "SPL", 7],
  ["SYS.1", "需求挖掘", "Requirements Elicitation", "SYS", 6],
  ["SYS.2", "系统需求分析", "System Requirements Analysis", "SYS", 8],
  ["SYS.3", "系统架构设计", "System Architectural Design", "SYS", 8],
  ["SYS.4", "系统集成与集成验证", "System Integration and Integration Verification", "SYS", 8],
  ["SYS.5", "系统验证", "System Verification", "SYS", 7],
  ["SWE.1", "软件需求分析", "Software Requirements Analysis", "SWE", 6],
  ["SWE.2", "软件架构设计", "Software Architectural Design", "SWE", 5],
  ["SWE.3", "软件详细设计与单元构建", "Software Detailed Design and Unit Construction", "SWE", 5],
  ["SWE.4", "软件单元验证", "Software Unit Verification", "SWE", 5],
  ["SWE.5", "软件组件验证与集成验证", "Software Component Verification and Integration Verification", "SWE", 7],
  ["SWE.6", "软件验证", "Software Verification", "SWE", 5],
  ["HWE.1", "硬件需求分析", "Hardware Requirements Analysis", "HWE", 8],
  ["HWE.2", "硬件设计", "Hardware Design", "HWE", 8],
  ["HWE.3", "硬件设计验证", "Verification against Hardware Design", "HWE", 7],
  ["HWE.4", "硬件需求验证", "Verification against Hardware Requirements", "HWE", 7],
  ["MLE.1", "机器学习需求分析", "Machine Learning Requirements Analysis", "MLE", 7],
  ["MLE.2", "机器学习架构", "Machine Learning Architecture", "MLE", 7],
  ["MLE.3", "机器学习训练", "Machine Learning Training", "MLE", 8],
  ["MLE.4", "机器学习模型测试", "Machine Learning Model Testing", "MLE", 8],
  ["SUP.1", "质量保证", "Quality Assurance", "SUP", 7],
  ["SUP.8", "配置管理", "Configuration Management", "SUP", 8],
  ["SUP.9", "问题解决管理", "Problem Resolution Management", "SUP", 7],
  ["SUP.10", "变更请求管理", "Change Request Management", "SUP", 6],
  ["MAN.3", "项目管理", "Project Management", "MAN", 10],
  ["REU.2", "复用产品管理", "Reuse Product Management", "REU", 7],
  ["PIM.3", "过程改进", "Process Improvement", "PIM", 8]
].map(([id, zh, en, group, bp]) => ({ id, zh, en, group, bp }));

export const PRACTICE_LIBRARY = {
  "SYS.3": [
    ["BP1", "建立系统架构", "定义系统元素、边界和分解原则，并与系统需求保持一致。"],
    ["BP2", "分配系统需求", "将需求分配至系统元素并保留双向追溯与分配理由。"],
    ["BP3", "定义接口", "定义内外部接口、数据、时序、资源与安全约束。"],
    ["BP4", "描述动态行为", "使用状态、序列或数据流视图描述关键动态行为。"],
    ["BP5", "评估架构方案", "基于质量属性与约束评估替代方案并记录决策。"],
    ["BP6", "确保一致性", "分析需求、架构视图和接口之间的一致性。"],
    ["BP7", "沟通架构", "向受影响方沟通架构及其变更并留存记录。"],
    ["BP8", "维护架构", "受控维护架构基线、变体及变更影响。"]
  ],
  "SWE.1": [
    ["BP1", "定义软件需求", "从系统需求、接口和运行环境约束推导并记录软件需求。"],
    ["BP2", "结构化软件需求", "按功能、非功能、接口、约束和变体建立可管理的软件需求结构。"],
    ["BP3", "分析软件需求", "分析正确性、完整性、可行性、可验证性、风险与优先级。"],
    ["BP4", "分析对运行环境的影响", "识别软件需求对运行环境、硬件资源和外部接口的影响。"],
    ["BP5", "确保一致性和建立双向可追溯性", "证明系统需求、软件需求、变更和后续工作产品之间一致且双向可追溯。"],
    ["BP6", "沟通约定的软件需求和运行环境影响", "对软件需求基线、未决项及运行环境影响进行评审、批准与沟通。"]
  ],
  "SWE.2": [
    ["BP1", "定义软件架构的静态方面", "定义软件组件、职责、分解、接口和部署关系。"],
    ["BP2", "定义软件架构的动态方面", "描述关键场景、状态、时序、并发、资源和异常行为。"],
    ["BP3", "分析软件架构", "针对质量属性、资源、功能安全、网络安全和技术约束分析架构方案。"],
    ["BP4", "确保一致性和建立双向可追溯性", "维护软件需求、架构元素、接口和架构决策之间一致性与双向追溯。"],
    ["BP5", "沟通约定的软件架构", "评审、批准并向开发和验证相关方沟通架构基线及变更影响。"]
  ],
  "SWE.3": [
    ["BP1", "开发软件详细设计", "将架构组件细化为可实现、可验证的软件单元设计。"],
    ["BP2", "构建软件单元", "依据详细设计和编码规范实现软件单元，并保留受控版本。"],
    ["BP3", "分析软件详细设计和软件单元", "分析接口、数据流、控制流、资源、复杂度和关键异常处理。"],
    ["BP4", "确保一致性和建立双向可追溯性", "证明架构、详细设计、代码和相关变更之间一致且双向可追溯。"],
    ["BP5", "沟通约定的软件详细设计和软件单元", "完成评审、问题闭环、批准和基线沟通。"]
  ],
  "SWE.4": [
    ["BP1", "开发软件单元验证措施", "定义验证对象、方法、覆盖准则、环境、期望结果和回归策略。"],
    ["BP2", "选择软件单元验证措施", "根据风险、变更影响和发布范围选择充分的验证集合。"],
    ["BP3", "验证软件单元", "在受控环境执行验证并保存原始结果、失败分析和复测记录。"],
    ["BP4", "确保一致性和建立双向可追溯性", "维护详细设计、软件单元、验证措施和结果之间的一致性与双向追溯。"],
    ["BP5", "汇总并沟通软件单元验证结果", "汇总覆盖、失败、偏差、剩余风险并完成评审和沟通。"]
  ],
  "SWE.5": [
    ["BP1", "开发软件集成策略", "定义集成顺序、增量、环境、入口/出口准则和回归策略。"],
    ["BP2", "开发软件集成验证措施", "建立针对组件交互和接口的验证措施、期望结果与覆盖准则。"],
    ["BP3", "选择软件集成验证措施", "根据架构、风险和变更范围选择验证集合。"],
    ["BP4", "集成软件组件和软件单元", "按策略执行集成并记录版本、环境、结果和异常。"],
    ["BP5", "执行软件集成验证", "执行选定措施并对失败、偏差和重新验证形成闭环。"],
    ["BP6", "确保一致性和建立双向可追溯性", "维护架构接口、组件、集成增量、验证措施和结果之间的双向追溯。"],
    ["BP7", "汇总并沟通软件集成验证结果", "汇总覆盖、质量状态、剩余风险并完成评审与沟通。"]
  ],
  "SWE.6": [
    ["BP1", "开发软件验证措施", "从软件需求和风险导出验证措施、环境、期望结果与覆盖准则。"],
    ["BP2", "选择软件验证措施", "根据发布范围、风险、变更和回归需要选择验证集合。"],
    ["BP3", "验证集成软件", "在代表性环境执行验证，保存结果并闭环失败和偏差。"],
    ["BP4", "确保一致性和建立双向可追溯性", "维护软件需求、验证措施、执行结果和缺陷之间一致性与双向追溯。"],
    ["BP5", "汇总并沟通软件验证结果", "汇总需求覆盖、通过率、剩余缺陷、偏差和发布风险。"]
  ],
  "SUP.1": [
    ["BP1", "制定质量保证策略", "定义独立性、范围、频率、准则、角色和升级路径。"],
    ["BP2", "保证工作产品质量", "按计划检查关键工作产品的完整性、一致性和符合性。"],
    ["BP3", "保证过程活动质量", "按计划检查过程活动是否符合适用流程、裁剪和承诺。"],
    ["BP4", "识别并记录不符合项", "客观记录不符合项、影响、责任人、截止时间和证据。"],
    ["BP5", "处理质量保证不符合项", "跟踪纠正措施、升级逾期事项并验证关闭有效性。"],
    ["BP6", "跟踪质量保证状态", "维护覆盖、趋势、开放风险和质量门状态。"],
    ["BP7", "沟通质量保证结果", "向管理层和相关方独立报告质量状态、重大偏差和剩余风险。"]
  ],
  "SUP.8": [
    ["BP1", "制定配置管理策略", "明确配置范围、角色、工具、基线和审计方式。"],
    ["BP2", "识别配置项", "识别配置项并维护标识、版本、状态和责任人。"],
    ["BP3", "建立配置管理系统", "提供访问、变更、备份、恢复和并发控制。"],
    ["BP4", "建立基线", "按计划建立可重现、获批并可追溯的基线。"],
    ["BP5", "控制变更", "配置项变更经授权、实施、验证并形成记录。"],
    ["BP6", "记录状态", "维护配置项与基线状态并生成状态报告。"],
    ["BP7", "验证完整性", "通过配置审计验证基线完整性和一致性。"],
    ["BP8", "管理存储与交付", "保护、归档、恢复并受控交付配置项和基线。"]
  ],
  "SUP.9": [
    ["BP1", "制定问题解决管理策略", "定义问题分类、优先级、角色、状态、升级和关闭准则。"],
    ["BP2", "识别并记录问题", "记录问题现象、环境、影响、发现版本和可复现信息。"],
    ["BP3", "调查并诊断问题", "完成根因、影响范围、相关工作产品和安全影响分析。"],
    ["BP4", "制定问题解决方案", "定义措施、责任人、计划、验证方法和回退方案。"],
    ["BP5", "实施并验证问题解决方案", "受控实施措施并通过复测或审查验证有效性。"],
    ["BP6", "跟踪问题状态", "监控时效、升级、关联变更、验证和关闭状态。"],
    ["BP7", "分析问题趋势", "分析重复问题、逃逸缺陷和系统性原因并推动预防措施。"]
  ],
  "SUP.10": [
    ["BP1", "制定变更请求管理策略", "定义变更入口、状态、角色、授权和关闭准则。"],
    ["BP2", "识别并记录变更请求", "记录变更原因、范围、优先级、来源和受影响对象。"],
    ["BP3", "分析变更请求", "分析技术、进度、成本、质量、安全和配置影响。"],
    ["BP4", "批准变更请求", "基于完整影响分析由授权角色作出可追溯决策。"],
    ["BP5", "实施并验证变更", "受控实施获批变更，更新受影响工作产品并完成验证。"],
    ["BP6", "跟踪并沟通变更状态", "维护状态、版本、验证、关闭和相关方沟通记录。"]
  ],
  "MAN.3": [
    ["BP1", "定义工作范围", "明确目标、范围、交付物、边界与假设。"],
    ["BP2", "定义生命周期", "选择生命周期、里程碑、过程与裁剪策略。"],
    ["BP3", "评估可行性", "评估目标、资源、进度、技术和依赖可行性。"],
    ["BP4", "定义活动与估算", "分解活动并估算工作量、资源与持续时间。"],
    ["BP5", "定义资源需求", "确定人员、技能、工具、环境和预算。"],
    ["BP6", "定义接口", "识别内部、外部及供应商接口和承诺。"],
    ["BP7", "制定项目计划", "建立一致、获批并可追踪的项目计划。"],
    ["BP8", "监控项目", "比较计划与实际，识别偏差和趋势。"],
    ["BP9", "采取纠正措施", "对偏差、问题和风险采取措施并验证效果。"],
    ["BP10", "沟通项目状态", "定期向利益相关方沟通客观项目状态。"]
  ],
  "SYS.1": [
    ["BP1", "识别利益相关方与需求来源", "识别客户、供应商、法规、标准、市场与内部利益相关方，并明确其需求来源和优先级。"],
    ["BP2", "获取并结构化利益相关方需求", "以可管理、可验证的方式捕获、分类并结构化利益相关方需求，含功能、非功能与约束。"],
    ["BP3", "分析利益相关方需求", "分析需求的正确性、完整性、可行性、一致性和可验证性，识别冲突与未决项。"],
    ["BP4", "确定影响运行环境的需求", "识别需求对运行环境、接口、资源、安全和法规的影响。"],
    ["BP5", "确保一致性和建立双向可追溯性", "证明利益相关方需求与系统需求、变更及后续工作产品之间一致且双向可追溯。"],
    ["BP6", "沟通约定的利益相关方需求", "评审、批准并向受影响方沟通需求基线、未决项和变更影响。"]
  ],
  "SYS.2": [
    ["BP1", "定义系统需求", "从利益相关方需求推导系统需求，含功能、性能、接口、约束和验证准则。"],
    ["BP2", "结构化系统需求", "按系统架构、接口、变体和验证范围组织可管理的系统需求结构。"],
    ["BP3", "分析系统需求", "分析正确性、完整性、可行性、可验证性、风险和优先级。"],
    ["BP4", "分析对运行环境的影响", "识别系统需求对运行环境、硬件资源、外部系统和安全约束的影响。"],
    ["BP5", "确定验证措施", "为关键系统需求定义可验证的验收准则和验证措施。"],
    ["BP6", "确保一致性和建立双向可追溯性", "维护利益相关方需求、系统需求、变更和后续工作产品之间的一致性与双向追溯。"],
    ["BP7", "评审并批准系统需求", "组织需求评审，闭环未决项并形成获批的系统需求基线。"],
    ["BP8", "沟通约定的系统需求", "向开发、验证、制造、采购和相关方沟通需求基线及变更影响。"]
  ],
  "SYS.4": [
    ["BP1", "制定系统集成策略", "定义集成顺序、增量、环境、入口和出口准则以及回归策略。"],
    ["BP2", "制定集成验证措施", "建立针对系统元素交互和接口的验证措施、期望结果与覆盖准则。"],
    ["BP3", "选择集成验证措施", "根据架构、风险和变更范围选择充分的集成验证集合。"],
    ["BP4", "集成系统元素", "按策略执行系统集成并记录版本、环境、结果和异常。"],
    ["BP5", "执行系统集成验证", "执行选定措施，并对失败、偏差和重新验证形成闭环。"],
    ["BP6", "确保一致性和建立双向可追溯性", "维护系统需求、架构接口、集成增量和验证结果之间的双向追溯。"],
    ["BP7", "汇总并沟通系统集成验证结果", "汇总覆盖、质量状态、剩余风险并完成评审与沟通。"],
    ["BP8", "管理集成环境与回归", "受控维护集成环境和配置，支持回归验证与变更影响分析。"]
  ],
  "SYS.5": [
    ["BP1", "制定系统验证措施", "从系统需求和风险导出验证措施、环境、期望结果与覆盖准则。"],
    ["BP2", "选择系统验证措施", "根据发布范围、风险、变更和回归需要选择验证集合。"],
    ["BP3", "执行系统验证", "在代表性环境执行验证，保存结果并闭环失败和偏差。"],
    ["BP4", "确保一致性和建立双向可追溯性", "维护系统需求、验证措施、执行结果和缺陷之间的一致性与双向追溯。"],
    ["BP5", "汇总并沟通系统验证结果", "汇总需求覆盖、通过率、剩余缺陷、偏差和发布风险。"],
    ["BP6", "评估发布准备度", "结合验证结果、未关闭问题、变更影响和残余风险形成发布判断。"],
    ["BP7", "管理验证环境与回归", "受控维护验证环境、工具和数据，支持回归验证与可复现性。"]
  ],
  "HWE.1": [
    ["BP1", "定义硬件需求", "从系统需求推导硬件需求，含功能、性能、接口、环境、可制造性和安全约束。"],
    ["BP2", "结构化硬件需求", "按硬件架构、接口、变体和验证范围组织可管理的硬件需求结构。"],
    ["BP3", "分析硬件需求", "分析正确性、完整性、可行性、可验证性、风险和优先级。"],
    ["BP4", "分析对运行环境的影响", "识别温度、振动、EMC、寿命、功率和外部接口等环境影响。"],
    ["BP5", "确定硬件验证措施", "为关键硬件需求定义可验证的验收准则、测试方法和覆盖要求。"],
    ["BP6", "确保一致性和建立双向可追溯性", "维护系统需求、硬件需求、变更和后续设计之间的一致性与双向追溯。"],
    ["BP7", "评审并批准硬件需求", "组织需求评审，闭环未决项并形成获批的硬件需求基线。"],
    ["BP8", "沟通约定的硬件需求", "向设计、验证、采购、制造和相关方沟通需求基线及变更影响。"]
  ],
  "HWE.2": [
    ["BP1", "定义硬件设计", "将硬件需求细化为原理图、布局、约束和可制造可验证的硬件设计。"],
    ["BP2", "定义硬件接口", "定义内外部电气、机械、热、信号和软件接口及其约束。"],
    ["BP3", "分析硬件设计", "分析时序、功耗、热、EMC、信号完整性、DFM、DFT 和失效模式。"],
    ["BP4", "描述动态行为", "使用状态、时序和场景视图描述关键动态行为与异常处理。"],
    ["BP5", "评估设计备选方案", "基于质量属性、成本、风险和约束评估替代方案并记录决策。"],
    ["BP6", "确保一致性和建立双向可追溯性", "维护硬件需求、设计元素、接口和变更之间的一致性与双向追溯。"],
    ["BP7", "评审并批准硬件设计", "组织设计评审，闭环未决项并形成获批的设计基线。"],
    ["BP8", "沟通约定的硬件设计", "向验证、制造、采购和相关方沟通设计基线及变更影响。"]
  ],
  "HWE.3": [
    ["BP1", "制定硬件设计验证措施", "针对硬件设计定义评审、仿真、样件测试等方法、期望结果与覆盖准则。"],
    ["BP2", "选择硬件设计验证措施", "根据设计风险、变更范围和验证层级选择充分的验证集合。"],
    ["BP3", "执行硬件设计验证", "在受控环境执行验证并保存原始结果、失败分析和复测记录。"],
    ["BP4", "确保一致性和建立双向可追溯性", "维护硬件设计、验证措施和结果之间的一致性与双向追溯。"],
    ["BP5", "汇总并沟通硬件设计验证结果", "汇总覆盖、失败、偏差、剩余风险并完成评审与沟通。"],
    ["BP6", "闭环设计问题和偏差", "对验证发现的缺陷和偏差完成根因分析、措施和重新验证。"],
    ["BP7", "管理验证环境与回归", "受控维护验证环境、样件、工具和数据，支持回归验证与可复现性。"]
  ],
  "HWE.4": [
    ["BP1", "制定硬件验证措施", "从硬件需求导出验证措施、环境、期望结果与覆盖准则。"],
    ["BP2", "选择硬件验证措施", "根据发布范围、风险、变更和回归需要选择验证集合。"],
    ["BP3", "执行硬件验证", "在代表性环境执行验证，保存结果并闭环失败和偏差。"],
    ["BP4", "确保一致性和建立双向可追溯性", "维护硬件需求、验证措施、执行结果和缺陷之间的一致性与双向追溯。"],
    ["BP5", "汇总并沟通硬件验证结果", "汇总需求覆盖、通过率、剩余缺陷、偏差和发布风险。"],
    ["BP6", "闭环硬件验证问题", "对验证失败和偏差完成根因分析、纠正措施、复测和授权关闭。"],
    ["BP7", "管理验证环境与回归", "受控维护验证环境、设备、工具和数据，支持回归验证与可复现性。"]
  ],
  "MLE.1": [
    ["BP1", "定义机器学习需求", "从系统需求推导机器学习功能、性能、数据、模型行为和安全约束。"],
    ["BP2", "定义数据需求", "明确训练、验证和测试数据的来源、范围、标注、质量、规模和版本要求。"],
    ["BP3", "分析机器学习需求", "分析正确性、完整性、可行性、可验证性、风险和优先级。"],
    ["BP4", "分析对运行环境的影响", "识别推理环境、算力、时延、数据分布漂移和安全边界的影响。"],
    ["BP5", "确定验证准则", "定义模型性能、泛化、鲁棒性和失效处理的可验证准则。"],
    ["BP6", "确保一致性和建立双向可追溯性", "维护系统需求、机器学习需求、数据、模型和验证结果之间的双向追溯。"],
    ["BP7", "沟通约定的机器学习需求", "评审、批准并向相关方沟通需求基线、未决项和变更影响。"]
  ],
  "MLE.2": [
    ["BP1", "定义机器学习架构", "定义数据流、特征工程、模型结构、训练/推理组件和部署边界。"],
    ["BP2", "定义组件接口", "定义机器学习组件与软件、数据管道、运行环境和外部系统的接口。"],
    ["BP3", "分析机器学习架构", "分析性能、资源、时延、安全、可解释性和失效行为。"],
    ["BP4", "定义数据管理与版本策略", "明确数据版本、模型版本、超参数、配置和实验记录的管理方式。"],
    ["BP5", "描述动态行为", "描述训练、推理、漂移检测、回退和异常处理等关键场景。"],
    ["BP6", "确保一致性和建立双向可追溯性", "维护机器学习需求、架构元素、数据、模型和验证之间的双向追溯。"],
    ["BP7", "沟通约定的机器学习架构", "评审、批准并向开发、验证和相关方沟通架构基线及变更影响。"]
  ],
  "MLE.3": [
    ["BP1", "定义训练策略", "明确训练流程、数据集划分、超参数、评估指标、环境和回归策略。"],
    ["BP2", "准备并验证数据集", "验证数据来源、标注质量、分布、去重和授权，确保数据可追溯。"],
    ["BP3", "执行机器学习训练", "在受控环境执行训练并记录数据版本、配置、参数和资源。"],
    ["BP4", "评估模型性能", "按定义指标评估训练结果并记录过拟合、欠拟合和偏差分析。"],
    ["BP5", "分析失效与边界行为", "分析模型在边界、对抗、分布外和失效场景下的行为。"],
    ["BP6", "建立模型和数据追溯", "记录数据、标注、代码、超参数、模型产物和需求之间的可复现追溯。"],
    ["BP7", "评审并批准训练结果", "组织评审，闭环未决项并形成获批的模型候选版本。"],
    ["BP8", "沟通训练结果", "向验证和相关方沟通模型能力、限制、风险和发布建议。"]
  ],
  "MLE.4": [
    ["BP1", "定义模型测试策略", "定义测试集、指标、通过准则、环境、覆盖范围和回归策略。"],
    ["BP2", "选择测试数据集", "选择代表性、独立且有统计意义的测试数据，避免与训练数据泄漏。"],
    ["BP3", "执行模型测试", "在受控环境执行测试并保存原始结果、失败分析和复测记录。"],
    ["BP4", "验证泛化与鲁棒性", "验证模型在分布内、分布外、扰动和边界条件下的表现。"],
    ["BP5", "分析失败并闭环问题", "对测试失败完成根因分析、数据或模型措施、重新验证和授权关闭。"],
    ["BP6", "确保一致性和建立双向可追溯性", "维护需求、测试措施、数据、模型版本和结果之间的双向追溯。"],
    ["BP7", "汇总并沟通测试结果", "汇总覆盖、通过率、剩余风险和发布建议并完成评审。"],
    ["BP8", "管理模型版本与回归", "受控维护模型、数据和测试环境版本，支持回归验证与可复现性。"]
  ],
  "ACQ.4": [
    ["BP1", "制定供应商监控策略", "定义监控范围、频次、准则、角色、升级路径和独立性与客观性要求。"],
    ["BP2", "监控供应商约定交付物", "按计划检查供应商过程和工作产品的状态、质量和承诺符合性。"],
    ["BP3", "评估供应商绩效", "基于质量、进度、风险和交付数据评估供应商绩效趋势。"],
    ["BP4", "识别并记录供应商偏差", "客观记录不符合项、影响、责任人、截止时间和证据。"],
    ["BP5", "处理供应商偏差与风险", "跟踪纠正措施、升级逾期事项并验证关闭有效性。"],
    ["BP6", "跟踪供应商问题状态", "维护供应商问题、依赖和风险的状态与趋势。"],
    ["BP7", "沟通供应商监控结果", "向管理层和相关方报告供应商绩效、重大偏差和剩余风险。"]
  ],
  "SPL.2": [
    ["BP1", "制定发布策略", "定义发布类型、范围、门禁、角色、准则和审批链。"],
    ["BP2", "定义发布内容与验收准则", "明确发布包内容、配置项清单、变体、文档和验收准则。"],
    ["BP3", "确认发布包完整性", "从获批基线装配发布包并验证可复现性、完整性和一致性。"],
    ["BP4", "评估发布就绪状态", "汇总验证覆盖、未关闭问题、残余风险和已知缺陷形成发布判断。"],
    ["BP5", "获得授权批准", "由授权角色基于就绪证据作出可追溯的发布批准决策。"],
    ["BP6", "执行并记录发布", "受控实施发布、记录版本和环境，并支持追溯与回退。"],
    ["BP7", "沟通发布状态", "向相关方沟通发布内容、状态、风险和后续支持信息。"]
  ],
  "REU.2": [
    ["BP1", "制定复用产品管理策略", "定义复用产品范围、识别准则、成熟度要求、责任和生命周期管理方式。"],
    ["BP2", "识别候选复用产品", "识别可复用的工作产品、组件、平台和资产并建立目录。"],
    ["BP3", "评估复用产品适用性", "评估复用产品的功能匹配、质量、安全、成本、风险和支持状态。"],
    ["BP4", "建立复用产品基线", "将获批的复用产品纳入受控基线并保留版本、状态和审批记录。"],
    ["BP5", "控制复用产品变更", "复用产品变更经影响分析、批准、验证并同步通知复用方。"],
    ["BP6", "提供使用信息与支持", "提供使用指南、限制、验证状态、已知问题和支持渠道。"],
    ["BP7", "监控复用效果", "跟踪复用率、缺陷、维护成本和价值，推动复用策略改进。"]
  ],
  "PIM.3": [
    ["BP1", "定义过程改进目标与范围", "基于业务目标、评估结果和过程数据明确改进目标、范围和准则。"],
    ["BP2", "分析过程基线数据", "收集并分析过程绩效、缺陷、成本和周期数据形成基线。"],
    ["BP3", "识别改进机会", "结合评估发现、问题趋势和利益相关方反馈识别改进机会并排序。"],
    ["BP4", "制定改进方案", "定义改进措施、责任人、资源、时间表、验证方法和沟通计划。"],
    ["BP5", "实施过程改进", "按方案受控实施改进并记录变更和影响。"],
    ["BP6", "验证改进有效性", "对照改进目标验证措施效果，确认问题消除且无负面回归。"],
    ["BP7", "标准化并沟通改进", "将有效改进纳入过程资产、培训和相关方沟通。"],
    ["BP8", "监控持续改进", "持续监控过程绩效和趋势，识别新的改进机会。"]
  ]
};

export const GP_LIBRARY = [
  ["GP 2.1.1", "识别目标并定义过程实施策略", "目标、范围、裁剪、约束和完成准则明确。"],
  ["GP 2.1.2", "计划过程的实施", "活动、里程碑、依赖、责任与输出纳入可执行计划。"],
  ["GP 2.1.3", "确定资源需求", "人员能力、工具、环境、信息和预算需求被识别。"],
  ["GP 2.1.4", "识别并提供资源", "资源按计划提供，可用性和能力满足过程需要。"],
  ["GP 2.1.5", "监控和调整过程的实施", "实际状态、偏差、趋势、措施和有效性可追踪。"],
  ["GP 2.1.6", "管理参与方之间的接口", "内部及外部接口、承诺、依赖和信息交换受管理。"],
  ["GP 2.2.1", "定义工作产品要求", "模板、必填字段、准则与完成定义明确。"],
  ["GP 2.2.2", "定义工作产品存储和控制要求", "评审、审批、配置、存储、访问与变更控制方式明确。"],
  ["GP 2.2.3", "识别并控制工作产品", "标识、版本、状态、基线和访问受控。"],
  ["GP 2.2.4", "评审并调整工作产品", "按准则评审并闭环问题，保持一致性。"]
];

export const EVIDENCE_GUIDE = {
  "SWE.1": ["软件需求规格", "需求评审记录", "系统↔软件需求追踪矩阵", "需求变更记录"],
  "SWE.2": ["软件架构设计", "接口规格", "动态行为/资源分析", "架构评审与需求↔架构追踪"],
  "SWE.3": ["软件详细设计", "代码/构建记录", "编码与静态检查结果", "设计评审与设计↔代码追踪"],
  "SWE.4": ["单元验证策略与规格", "原始测试结果/覆盖率", "详细设计↔单元↔测试追踪", "失败与复测闭环"],
  "SWE.5": ["软件集成策略", "集成增量与环境记录", "接口/集成验证结果", "架构↔集成↔验证追踪"],
  "SWE.6": ["软件验证策略/规格", "需求覆盖与执行结果", "缺陷和偏差闭环", "软件需求↔验证追踪"],
  "SUP.1": ["质量保证计划", "过程/工作产品审核记录", "不符合项与升级记录", "质量状态报告"],
  "SUP.8": ["配置管理计划", "配置项/基线清单", "变更与状态报告", "配置审计/备份恢复记录"],
  "SUP.9": ["问题管理流程", "问题单与根因分析", "措施/复测/关闭证据", "问题趋势统计"],
  "SUP.10": ["变更管理流程", "变更请求与影响分析", "审批/实施/验证记录", "变更↔工作产品追踪"],
  "MAN.3": ["项目计划与估算", "进度/里程碑监控", "风险问题与措施", "资源/接口/状态沟通记录"],
  "SYS.3": ["系统架构设计", "接口与动态行为视图", "架构分析/决策记录", "需求↔架构追踪与评审"],
  "SYS.1": ["利益相关方需求清单与来源记录", "需求获取/访谈/评审记录", "需求分类与优先级", "需求↔系统需求追踪"],
  "SYS.2": ["系统需求规格", "需求评审记录", "利益相关方↔系统需求追踪矩阵", "需求变更与影响记录"],
  "SYS.4": ["系统集成策略", "集成增量与环境记录", "接口/集成验证结果", "架构↔集成↔验证追踪"],
  "SYS.5": ["系统验证策略/规格", "需求覆盖与执行结果", "缺陷和偏差闭环", "系统需求↔验证追踪"],
  "HWE.1": ["硬件需求规格", "需求评审记录", "系统↔硬件需求追踪矩阵", "硬件需求变更记录"],
  "HWE.2": ["硬件设计文档", "接口与动态行为视图", "设计分析/决策记录", "需求↔设计追踪与评审"],
  "HWE.3": ["硬件设计验证策略与规格", "评审/仿真/样件测试结果", "设计↔验证追踪", "失败与复测闭环"],
  "HWE.4": ["硬件验证策略/规格", "需求覆盖与执行结果", "缺陷和偏差闭环", "硬件需求↔验证追踪"],
  "MLE.1": ["机器学习需求规格", "数据需求与来源记录", "需求评审与追溯矩阵", "需求变更记录"],
  "MLE.2": ["机器学习架构设计", "数据/模型版本策略", "架构分析与决策记录", "需求↔架构追踪与评审"],
  "MLE.3": ["训练策略与数据集记录", "训练配置/版本/日志", "模型性能与边界评估", "数据↔模型↔需求追踪"],
  "MLE.4": ["模型测试策略", "测试数据集与结果", "泛化/鲁棒性评估", "模型版本与回归记录"],
  "ACQ.4": ["供应商监控计划", "供应商交付状态与绩效记录", "不符合项与升级记录", "供应商问题关闭证据"],
  "SPL.2": ["发布策略与门禁", "发布包/基线清单", "发布就绪评估与批准", "发布记录与已知问题清单"],
  "REU.2": ["复用产品管理策略", "复用产品目录与基线", "复用评估与批准记录", "变更通知与使用信息"],
  "PIM.3": ["改进目标与范围", "过程基线数据与评估结果", "改进方案与实施记录", "有效性验证与标准化记录"]
};

export const ENGINEERING_CHAINS = [
  ["SYS.1", "SYS.2", "SYS.3", "SYS.4", "SYS.5"],
  ["SWE.1", "SWE.2", "SWE.3", "SWE.4", "SWE.5", "SWE.6"],
  ["HWE.1", "HWE.2", "HWE.3", "HWE.4"],
  ["MLE.1", "MLE.2", "MLE.3", "MLE.4"]
];

export const PROCESS_BRIDGES = [
  ["SYS.2", "SYS.5", "verification-pair", "系统资格验证应反向证明系统需求，覆盖、结果与偏差需双向追溯。"],
  ["SYS.3", "SYS.4", "integration-pair", "系统集成与集成验证应对照系统架构、接口和动态行为。"],
  ["SWE.1", "SWE.6", "verification-pair", "软件资格验证应反向证明软件需求及其验证准则。"],
  ["SWE.2", "SWE.5", "integration-pair", "软件集成验证应对照软件架构、接口和动态行为。"],
  ["SWE.3", "SWE.4", "unit-verification-pair", "软件单元验证应对照详细设计、单元要求和实现。"],
  ["SYS.2", "SWE.1", "allocation", "系统需求向软件需求分配，并传递接口、资源和验证约束。"],
  ["SYS.2", "HWE.1", "allocation", "系统需求向硬件需求分配，并传递接口、资源和验证约束。"],
  ["SWE.6", "SYS.4", "integration-input", "完成软件验证的受控版本和剩余问题进入系统集成。"],
  ["HWE.4", "SYS.4", "integration-input", "完成硬件需求验证的受控版本和剩余问题进入系统集成。"],
  ["SYS.5", "SPL.2", "release-input", "系统验证覆盖、偏差和剩余风险是产品发布决策输入。"],
  ["ACQ.4", "MAN.3", "supplier-dependency", "供应商承诺、交付状态和升级影响项目计划与纠正措施。"],
  ["SUP.1", "SUP.9", "nonconformance-to-problem", "质量保证发现的不符合项可进入问题解决过程并跟踪关闭。"],
  ["SUP.9", "SUP.10", "problem-to-change", "问题解决措施需要变更时，应建立问题与变更请求的双向追溯。"],
  ["SUP.8", "MAN.3", "configuration-status", "配置项和基线状态为项目进展、里程碑与偏差判断提供客观输入。"],
  ["SUP.8", "SPL.2", "release-baseline", "产品发布应从受控配置项和获批基线装配并验证完整性。"]
];

export const CROSS_PROCESS_PASSES = [
  ["qualified-flow", "合格输入 → 合格输出", "确认每个过程使用经评审/批准的输入，并向价值链下一过程提供合格输出。"],
  ["agree-summarize", "约定与汇总沟通", "检查需求/设计是否达成共同理解，验证结果、策略、计划和状态是否被汇总并沟通。"],
  ["divide-control", "分解、委派、集成与控制", "检查系统—域—组件—单元分解、责任委派，以及按设计逐级集成验证。"],
  ["trace-consistency", "追溯、一致性、影响与完整性", "沿来源与验证双向追溯，检查语义一致、变更影响和覆盖完整性。"]
];

export const SUPPORT_PROCESS_RELATIONS = [
  ["MAN.3", "governance", "计划、依赖、资源、接口、里程碑监控和纠正措施"],
  ["SUP.1", "assurance", "独立质量保证覆盖、不符合项升级和关闭有效性"],
  ["SUP.8", "configuration", "配置项标识、版本、基线、状态、完整性和可重现性"],
  ["SUP.9", "problem", "问题关联、根因、影响、修复验证、趋势和关闭"],
  ["SUP.10", "change", "变更请求、跨过程影响、批准、实施、验证和关闭"]
];

export const REVIEW_WORKFLOW = [
  ["upload", "上传证据包", "接收 DOCX、PPTX、XLSX/XLSM、PDF 与文本证据。"],
  ["parse", "本地解析与映射", "读取正文、表格、Sheet/Slide、Helix 字段和稳定来源定位。"],
  ["review", "全证据 AI 复核", "按过程、BP/GP、证据强度与跨文件依赖生成候选结论。"],
  ["support", "SUP 闭环检查", "联合检查 SUP.8 配置、SUP.9 问题与 SUP.10 变更链。"],
  ["dependency", "依赖与影响分析", "识别上下游工作产品、跨过程关系和断裂点。"],
  ["gate", "评估师确认与导出", "人工改判、记录理由、通过质量门禁后形成报告。"]
];

export const HELIX_FIELD_GROUPS = [
  ["identity", "唯一标识", ["item id", "requirement id", "issue id", "defect id", "problem id", "cr id", "change id", "test id", "id", "编号", "标识"]],
  ["content", "对象内容", ["title", "summary", "description", "requirement", "text", "name", "标题", "摘要", "描述", "需求"]],
  ["state", "状态", ["state", "status", "workflow", "resolution", "状态", "阶段", "解决状态"]],
  ["ownership", "责任与批准", ["owner", "author", "assignee", "reviewer", "approver", "approved by", "责任人", "作者", "审核人", "批准人"]],
  ["control", "版本与基线", ["version", "revision", "baseline", "build", "modified", "updated", "版本", "修订", "基线", "更新时间"]],
  ["trace", "上下游追溯", ["upstream", "downstream", "parent", "child", "trace", "linked", "relationship", "source id", "target id", "上游", "下游", "父项", "子项", "追溯", "关联"]],
  ["impact", "影响与闭环", ["impact", "root cause", "verification", "closure", "closed by", "change request", "problem", "affected", "影响", "根因", "验证", "关闭", "变更", "问题", "受影响"]]
];

export const HELIX_STATUS_TERMS = {
  open: ["open", "new", "draft", "active", "in progress", "analysis", "处理中", "打开", "新建", "草稿"],
  review: ["review", "verify", "verification", "approval", "pending", "待评审", "待验证", "待批准", "审核中"],
  closed: ["closed", "done", "resolved", "approved", "verified", "complete", "已关闭", "完成", "已解决", "已批准", "已验证"],
  blocked: ["blocked", "rejected", "overdue", "failed", "阻塞", "拒绝", "逾期", "失败"]
};

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------
export function esc(value) {
  return String(value == null ? "" : value).replace(/[&<>'"]/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[ch]);
}
export function formatDate(value) {
  const d = value ? new Date(value) : new Date();
  return Number.isNaN(d.getTime()) ? "—" : new Intl.DateTimeFormat("zh-CN", { year: "numeric", month: "2-digit", day: "2-digit" }).format(d);
}
export function deepCopy(value) { return JSON.parse(JSON.stringify(value)); }
export function id(prefix = "id") { return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`; }
export function clampScore(value) { return Math.max(0, Math.min(100, Math.round(value))); }
export function canonicalCode(code) { return String(code || "").replace(/\s+/g, ""); }
export function averageRating(items = []) {
  if (!items.length) return "—";
  const avg = items.reduce((sum, item) => sum + (RATING_SCORE[item.rating] || 0), 0) / items.length;
  return RATING_ORDER.reduce((best, r) => Math.abs(RATING_SCORE[r] - avg) < Math.abs(RATING_SCORE[best] - avg) ? r : best, "N");
}
// v6.6: PA ratings use a veto guardrail before averaging. Any N/P indicator
// blocks an attribute from reaching L; any below-F indicator blocks PA 1.1
// from reaching F. This prevents a single missing practice from being hidden
// by an arithmetic average when computing CL1/CL2 gates.
export function aggregatePaRating(items = [], pa = "PA 1.1") {
  if (!items.length) return "—";
  const belowL = items.filter(item => (RATING_SCORE[item.rating] || 0) < 50);
  const belowF = items.filter(item => (RATING_SCORE[item.rating] || 0) < 85);
  const rating = averageRating(items);
  if (belowL.length) return "P+";
  if (pa === "PA 1.1" && belowF.length) return "L+";
  return rating;
}
export function ratingClass(rating) { return ["F", "L+", "L"].includes(rating) ? "success" : ["L-", "P+", "P"].includes(rating) ? "warn" : "danger"; }
export function ratingMeets(rating, threshold) { return (RATING_SCORE[rating] || 0) >= (threshold === "F" ? 85 : threshold === "L" ? 50 : threshold === "P" ? 15 : 0); }
export function sufficiencyLabel(status) { return status === "sufficient" ? "证据充分" : status === "partial" ? "证据部分充分" : "证据不足"; }
export function processName(processId) { const item = PROCESS_CATALOG.find(process => process.id === processId); return item ? `${item.id} ${item.zh}` : processId; }
export function processReportName(processId) { const proc = PROCESS_CATALOG.find(p => p.id === processId); return proc ? `${proc.id} ${proc.en} / ${proc.zh}` : processId; }
export function indicatorKey(a) { return a.process === "CUSTOM" ? a.code : `${a.process}.${canonicalCode(a.code)}`; }

export function normalizeCell(value) { return String(value == null ? "" : value).replace(/\s+/g, " ").trim(); }
export function uniqueHeaders(values, count) {
  const used = new Map();
  return Array.from({ length: count }, (_, index) => {
    const raw = normalizeCell(values[index]) || `Column ${index + 1}`;
    const seen = (used.get(raw) || 0) + 1; used.set(raw, seen);
    return seen === 1 ? raw : `${raw} (${seen})`;
  });
}
export function helixFieldMatches(headers) {
  const normalized = headers.map(value => normalizeCell(value).toLowerCase());
  const groups = {};
  HELIX_FIELD_GROUPS.forEach(([key, label, terms]) => {
    const columns = [];
    normalized.forEach((header, index) => { if (terms.some(term => header === term || header.includes(term))) columns.push(index); });
    groups[key] = { label, columns, headers: columns.map(index => headers[index]) };
  });
  return groups;
}
export function classifyHelixStatus(value) {
  const text = normalizeCell(value).toLowerCase();
  return Object.entries(HELIX_STATUS_TERMS).find(([, terms]) => terms.some(term => text === term || text.includes(term)))?.[0] || "other";
}
export function makeEvidenceTable(name, source, rawRows, options = {}) {
  const rows = (rawRows || []).map(row => (row || []).slice(0, 24).map(normalizeCell));
  const meaningful = rows.filter(row => row.some(Boolean));
  if (!meaningful.length) return null;
  const headerIndex = Math.max(0, meaningful.findIndex(row => row.filter(Boolean).length >= 2));
  const usable = meaningful.slice(headerIndex);
  const columnCount = Math.min(24, Math.max(1, ...usable.map(row => row.length)));
  const headers = uniqueHeaders(usable[0] || [], columnCount);
  const allRecords = usable.slice(1).filter(row => row.some(Boolean));
  const maxRows = Math.max(20, Math.min(200, Number(options.helixMaxRows || 60)));
  const records = allRecords.slice(0, maxRows).map(row => Array.from({ length: columnCount }, (_, index) => normalizeCell(row[index])));
  const groups = helixFieldMatches(headers);
  const detectedGroups = Object.entries(groups).filter(([, value]) => value.columns.length).map(([key]) => key);
  const stateColumns = groups.state.columns;
  const traceColumns = groups.trace.columns;
  const statusCounts = { open: 0, review: 0, closed: 0, blocked: 0, other: 0 };
  records.forEach(row => stateColumns.forEach(index => statusCounts[classifyHelixStatus(row[index])]++));
  const linkedRows = records.filter(row => traceColumns.some(index => normalizeCell(row[index]))).length;
  const helixScore = Math.round(detectedGroups.length / HELIX_FIELD_GROUPS.length * 100);
  const helixDetected = (options.helixRequireIdentity ?? true) ? !!groups.identity.columns.length && (!!groups.state.columns.length || !!groups.trace.columns.length || !!groups.control.columns.length) : detectedGroups.length >= 3;
  return {
    name: normalizeCell(name) || "Table",
    source: normalizeCell(source) || "Document",
    headers,
    rows: records,
    rowCount: allRecords.length,
    columnCount,
    truncated: allRecords.length > records.length,
    helix: {
      detected: helixDetected,
      score: helixScore,
      groups: detectedGroups,
      fields: Object.fromEntries(Object.entries(groups).filter(([, value]) => value.columns.length).map(([key, value]) => [key, value.headers])),
      missing: HELIX_FIELD_GROUPS.filter(([key]) => !detectedGroups.includes(key)).map(([, label]) => label),
      statusCounts,
      linkedRows
    }
  };
}
export function summarizeHelixTables(tables) {
  const detected = (tables || []).filter(table => table.helix?.detected);
  const groups = [...new Set(detected.flatMap(table => table.helix.groups || []))];
  const statusCounts = { open: 0, review: 0, closed: 0, blocked: 0, other: 0 };
  detected.forEach(table => Object.keys(statusCounts).forEach(key => statusCounts[key] += Number(table.helix.statusCounts?.[key] || 0)));
  return {
    detected: !!detected.length,
    tableCount: detected.length,
    rowCount: detected.reduce((sum, table) => sum + Number(table.rowCount || 0), 0),
    score: detected.length ? Math.round(detected.reduce((sum, table) => sum + table.helix.score, 0) / detected.length) : 0,
    groups,
    fields: [...new Set(detected.flatMap(table => Object.values(table.helix.fields || {}).flat()))],
    missing: HELIX_FIELD_GROUPS.filter(([key]) => !groups.includes(key)).map(([, label]) => label),
    linkedRows: detected.reduce((sum, table) => sum + Number(table.helix.linkedRows || 0), 0),
    statusCounts
  };
}
export function tablesToEvidenceText(tables) {
  const lines = [];
  (tables || []).slice(0, 18).forEach(table => {
    lines.push(`[${table.source} · ${table.name}] ${table.headers.join(" | ")}`);
    table.rows.slice(0, 30).forEach((row, index) => {
      const values = row.map((value, column) => value ? `${table.headers[column]}=${value}` : "").filter(Boolean);
      if (values.length) lines.push(`[${table.source} · ${table.name} · Row ${index + 2}] ${values.join(" | ")}`);
    });
  });
  return lines.join("\n");
}
export function tableLocators(tables) {
  return (tables || []).flatMap(table => table.rows.slice(0, 3).map((row, index) => ({
    locator: `${table.source} · ${table.name} · Row ${index + 2}`,
    excerpt: row.map((value, column) => value ? `${table.headers[column]}=${value}` : "").filter(Boolean).join(" | ").slice(0, 260)
  }))).filter(item => item.excerpt).slice(0, 12);
}

// ---------------------------------------------------------------------------
// Process / evidence relation logic
// ---------------------------------------------------------------------------
export function processIdsFromText(text) {
  const value = String(text || "").toLowerCase();
  return PROCESS_CATALOG.filter(process => {
    const id = process.id.toLowerCase();
    const compact = id.replace(".", "");
    return value.includes(id) || value.includes(compact) || value.includes(process.zh.toLowerCase()) || value.includes(process.en.toLowerCase());
  }).map(process => process.id);
}
export function inferEvidencePrimaryProcesses(evidence, formalProcesses = []) {
  const stored = Array.isArray(evidence.primaryProcesses) ? evidence.primaryProcesses.filter(Boolean) : [];
  const explicit = processIdsFromText(evidence.scope);
  const inferred = processIdsFromText(`${evidence.name || ""} ${String(evidence.content || "").slice(0, 12000)} ${tablesToEvidenceText(evidence.tables || []).slice(0, 12000)}`);
  const detected = [...new Set([...stored, ...explicit, ...inferred])];
  if (detected.length) return detected;
  const scope = String(evidence.scope || "").toLowerCase();
  return (!scope || scope.includes("全部") || scope.includes("all")) ? [...formalProcesses] : [];
}
export function suggestedEvidenceScope(name, formalProcesses = []) {
  const inferred = processIdsFromText(name).filter(pid => formalProcesses.includes(pid));
  return inferred.length ? inferred.join("、") : "全部审核项";
}
export function relatedProcessesFor(processId, formalProcesses = []) {
  const relations = [];
  ENGINEERING_CHAINS.forEach(chain => {
    const index = chain.indexOf(processId); if (index < 0) return;
    if (index > 0) relations.push({ sourceProcess: chain[index - 1], targetProcess: processId, relatedProcess: chain[index - 1], relationType: "upstream", rationale: `检查来自 ${chain[index - 1]} 的输入、批准、追溯和变更是否完整。` });
    if (index < chain.length - 1) relations.push({ sourceProcess: processId, targetProcess: chain[index + 1], relatedProcess: chain[index + 1], relationType: "downstream", rationale: `检查 ${chain[index + 1]} 是否正确消费输出并反馈验证或集成问题。` });
  });
  PROCESS_BRIDGES.forEach(([sourceProcess, targetProcess, relationType, rationale]) => {
    if (processId === sourceProcess) relations.push({ sourceProcess, targetProcess, relatedProcess: targetProcess, relationType, rationale });
    else if (processId === targetProcess) relations.push({ sourceProcess, targetProcess, relatedProcess: sourceProcess, relationType: "upstream", rationale });
  });
  const support = SUPPORT_PROCESS_RELATIONS.find(item => item[0] === processId);
  if (support) {
    formalProcesses.filter(pid => pid !== processId).forEach(targetProcess => relations.push({ sourceProcess: processId, targetProcess, relatedProcess: targetProcess, relationType: support[1], rationale: `通过 ${processId} 检查${support[2]}。` }));
  } else {
    SUPPORT_PROCESS_RELATIONS.forEach(([sourceProcess, relationType, focus]) => relations.push({ sourceProcess, targetProcess: processId, relatedProcess: sourceProcess, relationType, rationale: `通过 ${sourceProcess} 检查${focus}。` }));
  }
  const seen = new Set();
  return relations.filter(relation => {
    const key = `${relation.sourceProcess}|${relation.targetProcess}|${relation.relationType}`;
    if (seen.has(key) || relation.relatedProcess === processId) return false;
    seen.add(key); return true;
  }).map(relation => ({ ...relation, scopeStatus: formalProcesses.includes(relation.relatedProcess) ? "in-scope" : "related-only" }));
}
export function evidenceRelationToProcess(evidence, processId, formalProcesses = []) {
  const primary = inferEvidencePrimaryProcesses(evidence, formalProcesses);
  if (primary.includes(processId)) return { sourceProcess: processId, targetProcess: processId, relatedProcess: processId, relationType: "direct", scopeStatus: "in-scope" };
  const relations = relatedProcessesFor(processId, formalProcesses);
  return relations.find(relation => primary.includes(relation.relatedProcess)) || null;
}
export function evidenceAppliesTo(evidence, processId, formalProcesses = []) {
  return !!evidenceRelationToProcess(evidence, processId, formalProcesses);
}
export function relationLabel(type) {
  return ({ direct: "直接", upstream: "上游", downstream: "下游", allocation: "分配", governance: "项目治理", assurance: "质量保证", configuration: "配置管理", problem: "问题管理", change: "变更管理", "verification-pair": "需求↔资格验证", "integration-pair": "架构↔集成验证", "unit-verification-pair": "详细设计↔单元验证", "integration-input": "集成输入", "release-input": "发布输入", "supplier-dependency": "供应商依赖", "nonconformance-to-problem": "不符合项→问题", "problem-to-change": "问题→变更", "configuration-status": "配置状态→项目状态", "release-baseline": "基线→发布" })[type] || type;
}
export function buildCrossProcessAnalysis(processId, evidence = [], formalProcesses = []) {
  return relatedProcessesFor(processId, formalProcesses).map(relation => {
    const relatedEvidence = evidence.filter(item => inferEvidencePrimaryProcesses(item, formalProcesses).includes(relation.relatedProcess));
    const evidenceCodes = relatedEvidence.map(item => item.code).filter(Boolean).slice(0, 5);
    const hasDirectText = relatedEvidence.some(item => String(item.content || "").trim().length >= 120);
    const helixRows = relatedEvidence.reduce((sum, item) => sum + Number(item.helix?.rowCount || 0), 0);
    const helixTraceRows = relatedEvidence.reduce((sum, item) => sum + Number(item.helix?.linkedRows || 0), 0);
    const passIds = (relation.relationType === "governance" ? ["agree-summarize", "divide-control"] : relation.relationType === "configuration" ? ["qualified-flow", "trace-consistency"] : ["qualified-flow", "agree-summarize", "trace-consistency"]);
    if (["integration-pair", "unit-verification-pair", "integration-input"].includes(relation.relationType)) passIds.push("divide-control");
    return {
      ...relation,
      analysisPasses: [...new Set(passIds)],
      evidenceCodes,
      helixRows,
      helixTraceRows,
      supportedClaim: evidenceCodes.length ? `${relation.rationale}${helixRows ? ` 已读取 Helix 表格 ${helixRows} 行，其中 ${helixTraceRows} 行具有关系字段；需继续核实关系类型、版本和两端状态。` : hasDirectText ? " 已发现可定位的关联内容，仍需核实接口两侧一致性。" : " 当前只有文件索引或元数据。"}` : "尚无关联证据支持该关系。",
      gapOrRisk: evidenceCodes.length ? (hasDirectText ? "关联证据只能用于交叉佐证，不能替代目标过程的直接实施证据。" : "缺少可定位正文，无法验证版本、批准和闭环。") : `${relation.relatedProcess} 的输入/治理/反馈未被当前证据包覆盖。`,
      followUp: evidenceCodes.length ? `抽查 ${relation.relatedProcess} 与 ${processId} 的双向链接、相同版本和关闭状态。` : `补充 ${relation.relatedProcess} 的受控记录，并访谈关系两侧责任人。`
    };
  });
}
export function crossProcessSummary(project, processId) { return buildCrossProcessAnalysis(processId, project.evidence || [], project.processes || []); }
// v6.7: display-level scope guard. Only relations between processes selected
// by the customer are shown in project/report surfaces; the internal relation
// model still classifies corroborating evidence correctly.
export function visibleCrossRows(project, processId) {
  const selected = project.processes || [];
  return crossProcessSummary(project, processId).filter(row => selected.includes(row.targetProcess));
}

// ---------------------------------------------------------------------------
// Assessment core (server-side rule engine)
// ---------------------------------------------------------------------------
export function processAssessments(project, processId, pa) { return (project.assessments || []).filter(item => item.process === processId && (!pa || item.pa === pa)); }
export function processPaRating(project, processId, pa) { return aggregatePaRating(processAssessments(project, processId, pa), pa); }
export function processCapability(project, processId) {
  if (project.importSource && project.processResults?.length) return Number(project.processResults.find(item => item.id === processId)?.achievedLevel || 0);
  const pa11 = processPaRating(project, processId, "PA 1.1");
  const pa21 = processPaRating(project, processId, "PA 2.1");
  const pa22 = processPaRating(project, processId, "PA 2.2");
  if (ratingMeets(pa11, "F") && ratingMeets(pa21, "L") && ratingMeets(pa22, "L")) return 2;
  if (ratingMeets(pa11, "L")) return 1;
  return 0;
}
export function achievedLevel(project) {
  if (!(project.assessments || []).length) return "—";
  const levels = (project.processes || []).map(processId => processCapability(project, processId));
  return `Level ${levels.length ? Math.min(...levels) : 0}`;
}
export function refreshProjectOutcome(project) {
  if (project.importSource && project.processResults?.length) { project.achievedLevel = `Level ${Math.min(...project.processResults.map(item => Number(item.achievedLevel || 0)))}`; return project.achievedLevel; }
  project.achievedLevel = achievedLevel(project);
  return project.achievedLevel;
}
export function assessmentQuality(project) {
  const items = project.assessments || [];
  const insufficient = items.filter(item => item.evidenceSufficiency?.status === "insufficient" || !(item.refs || []).length).length;
  const partial = items.filter(item => item.evidenceSufficiency?.status === "partial").length;
  const unreviewed = items.filter(item => !item.reviewed).length;
  const lowConfidence = items.filter(item => Number(item.confidence || 0) < 70).length;
  const missingFinding = items.filter(item => RATING_SCORE[item.rating] < 85 && !(item.findings || []).some(f => f.type === "W" || f.type === "R")).length;
  const cited = items.reduce((sum, item) => sum + (item.evidenceAnalysis?.length || 0), 0);
  const coverage = items.length ? Math.round(items.reduce((sum, item) => sum + Number(item.evidenceSufficiency?.coverage || 0), 0) / items.length) : 0;
  const relationRows = (project.processes || []).flatMap(processId => crossProcessSummary(project, processId));
  const relatedGaps = relationRows.filter(item => !item.evidenceCodes.length).length;
  return { insufficient, partial, unreviewed, lowConfidence, missingFinding, cited, coverage, relatedGaps, ready: !!items.length && !insufficient && !partial && !unreviewed && !missingFinding };
}
export function traceLinksForAssessment(project, assessment) {
  if (!assessment) return [];
  const key = indicatorKey(assessment);
  const links = new Map();
  (assessment.evidenceAnalysis || []).forEach((item, index) => {
    const relationKey = item.evidenceId || item.evidenceCode || `AUTO-${index}`;
    links.set(relationKey, { id: `AUTO-${assessment.id}-${index}`, indicator: key, evidenceId: item.evidenceId, evidenceCode: item.evidenceCode, strength: item.strength, relationType: item.relationType || "direct", locator: item.locator, claim: item.claim, source: "AI inferred", confirmed: false });
  });
  (project.traceLinks || []).filter(link => link.indicator === key).forEach(link => {
    const relationKey = link.evidenceId || link.evidenceCode || link.id;
    links.set(relationKey, { ...links.get(relationKey), ...link, source: "Assessor confirmed", confirmed: true });
  });
  return [...links.values()];
}
export function traceCoverage(project) {
  const assessments = project.assessments || [];
  const links = assessments.flatMap(item => traceLinksForAssessment(project, item));
  const direct = assessments.filter(item => traceLinksForAssessment(project, item).some(link => link.strength === "direct")).length;
  const linked = assessments.filter(item => traceLinksForAssessment(project, item).length).length;
  const confirmed = new Set((project.traceLinks || []).map(link => `${link.indicator}|${link.evidenceId}`)).size;
  const blocked = (project.evidence || []).reduce((sum, item) => sum + Number(item.helix?.statusCounts?.blocked || 0), 0);
  return { total: assessments.length, direct, linked, gaps: Math.max(0, assessments.length - linked), confirmed, linkCount: links.length, blocked, directPercent: assessments.length ? Math.round(direct / assessments.length * 100) : 0, linkedPercent: assessments.length ? Math.round(linked / assessments.length * 100) : 0 };
}
export function projectProgressStages(project) {
  const quality = assessmentQuality(project);
  const trace = traceCoverage(project);
  const finalized = (project.records || []).filter(record => record.status === "Final").length;
  return [
    { name: "范围与计划", value: (project.instances?.length && project.processes?.length) ? 100 : 35, detail: `${project.processes?.length || 0} 过程 · ${project.instances?.length || 0} 实例` },
    { name: "证据准备", value: project.evidence?.length ? Math.round((project.evidence.filter(item => item.parseStatus === "parsed").length / project.evidence.length) * 100) : 0, detail: `${project.evidence?.length || 0} 份证据` },
    { name: "指标追溯", value: trace.linkedPercent, detail: `${trace.linked}/${trace.total} 指标已关联` },
    { name: "人工复核", value: project.assessments?.length ? Math.round(project.assessments.filter(item => item.reviewed).length / project.assessments.length * 100) : 0, detail: `${quality.unreviewed} 项待复核` },
    { name: "记录定稿", value: project.records?.length ? Math.round(finalized / project.records.length * 100) : 0, detail: `${finalized}/${project.records?.length || 0} 已定稿` },
    { name: "关闭门禁", value: project.assessmentState === "Closed" ? 100 : quality.ready ? 82 : Math.max(8, Math.round((quality.coverage || 0) * .72)), detail: project.assessmentState === "Closed" ? "已关闭" : quality.ready ? "可进入关闭" : "仍有阻塞" }
  ];
}
export function ratingCappedByEvidence(candidate, sufficiency) {
  if (sufficiency.status === "insufficient") return "N";
  const max = sufficiency.directCount ? (sufficiency.citedCount >= 2 ? "L+" : "L-") : (sufficiency.citedCount >= 2 ? "P+" : "P");
  return RATING_SCORE[candidate] <= RATING_SCORE[max] ? candidate : max;
}
// v6.6: local candidates are derived from evidence strength instead of a
// rotating template. F remains reserved for provider-reviewed multi-cycle
// closure evidence; local candidates range N..L+.
export function evidenceScoreRating(sufficiency, analysis = []) {
  if (!sufficiency || sufficiency.status === "insufficient") return "N";
  const direct = Number(sufficiency.directCount || 0);
  const cited = Number(sufficiency.citedCount || 0);
  const corroborating = Number(sufficiency.corroboratingCount || 0);
  const closureSignals = analysis.reduce((sum, item) => sum + (item.helixStatusCounts ? Number(item.helixStatusCounts.closed || 0) + Number(item.helixStatusCounts.review || 0) : 0), 0);
  const hasHelix = analysis.some(item => item.helixTable);
  let rating = "N";
  if (direct >= 3 && sufficiency.status === "sufficient" && closureSignals >= 2 && hasHelix) rating = "L+";
  else if (direct >= 2 && cited >= 3 && sufficiency.status === "sufficient") rating = "L";
  else if (direct >= 1) rating = "L-";
  else if (corroborating >= 2) rating = "P+";
  else if (corroborating >= 1) rating = "P";
  else if (cited >= 1) rating = "P-";
  return rating;
}
export function makeScoreBreakdown(rating, index, sufficiency) {
  const base = RATING_SCORE[rating];
  const robust = sufficiency?.status === "sufficient" && Number(sufficiency.directCount || 0) >= 2;
  return {
    definition: clampScore(base - (sufficiency?.status === "sufficient" ? 2 : 15)),
    implementation: clampScore(base - (Number(sufficiency?.directCount || 0) >= 2 ? 2 : 15)),
    consistency: clampScore(base - (Number(sufficiency?.citedCount || 0) < 2 ? 18 : 4)),
    governance: clampScore(base - (Number(sufficiency?.directCount || 0) ? 5 : 18)),
    closure: clampScore(base - (robust ? 4 : 20))
  };
}
export function assessmentRequirements(processId, kind, pa) {
  if (kind === "BP") return EVIDENCE_GUIDE[processId] || ["过程定义或计划", "项目执行样本", "评审/批准记录", "追溯或闭环记录"];
  return pa === "PA 2.1"
    ? ["过程目标与策略", "项目级过程计划", "资源与职责", "周期监控/偏差措施", "接口沟通记录"]
    : ["工作产品准则", "评审与批准", "配置/版本/基线", "变更与问题闭环"];
}
export function makeEvidenceAnalysis(evidence, processId, criterion, requirements, formalProcesses = []) {
  const evidenceRank = ({ item, relation }) => (relation.relationType === "direct" ? 100 : 0) + (item.helix?.detected ? 40 : 0) + ((item.tables || []).some(table => table.rowCount > 0) ? 25 : 0) + (String(item.content || "").trim().length >= 120 ? 15 : 0) + ((item.locators || []).length ? 5 : 0);
  return (evidence || []).map(item => ({ item, relation: evidenceRelationToProcess(item, processId, formalProcesses) })).filter(entry => entry.relation).sort((a, b) => evidenceRank(b) - evidenceRank(a)).slice(0, 5).map(({ item, relation }, index) => {
    const content = String(item.content || "").replace(/\s+/g, " ").trim();
    const tableLocator = (item.locators || [])[index % (item.locators?.length || 1)];
    const direct = content.length >= 120 || (item.tables || []).some(table => table.rowCount > 0);
    const strength = !direct ? "index-only" : relation.relationType === "direct" ? "direct" : "corroborating";
    return {
      evidenceId: item.id,
      evidenceCode: item.code || `EV.${String(index + 1).padStart(3, "0")}`,
      source: item.name,
      locator: direct ? (tableLocator?.locator || `正文摘录 · 字符 1–${Math.min(content.length, 220)}`) : "文件索引 · 待审核员打开原文定位",
      excerpt: direct ? (tableLocator?.excerpt || content.slice(0, 220)) : `已登记“${item.name}”的文件元数据，但当前工作区未保留可引用正文。`,
      claim: relation.relationType === "direct" ? `用于直接核实：${criterion}` : `用于交叉核实 ${relation.relatedProcess} 与 ${processId} 的${relationLabel(relation.relationType)}关系；不得替代目标过程直接证据。`,
      dimension: requirements[index % requirements.length],
      strength,
      helixTable: !!item.helix?.detected,
      helixStatusCounts: item.helix?.statusCounts || null,
      originProcess: relation.sourceProcess,
      targetProcess: processId,
      relatedProcess: relation.relatedProcess,
      relationType: relation.relationType,
      scopeStatus: relation.scopeStatus
    };
  });
}
export function buildEvidenceSufficiency(analysis, requirements) {
  const direct = analysis.filter(item => item.strength === "direct").length;
  const corroborating = analysis.filter(item => item.strength === "corroborating").length;
  const observed = analysis.length;
  const status = direct >= 2 && observed >= 2 ? "sufficient" : observed ? "partial" : "insufficient";
  const coverage = status === "sufficient" ? Math.min(100, 82 + observed * 5) : status === "partial" ? Math.min(76, 26 + observed * 18 + direct * 12) : 0;
  const coveredTypes = requirements.slice(0, Math.min(requirements.length, direct + Math.ceil(observed / 2)));
  return {
    status,
    coverage,
    citedCount: observed,
    directCount: direct,
    corroboratingCount: corroborating,
    minimumSampleCount: 3,
    observedSampleCount: observed,
    coveredTypes,
    missingTypes: requirements.filter(item => !coveredTypes.includes(item))
  };
}
function buildProfessionalAssessment({ processId, processName, kind, pa, practice, index, pIndex, seedOffset, evidence, formalProcesses }) {
  const [code, title, criterion] = practice;
  const requirements = assessmentRequirements(processId, kind, pa);
  const evidenceAnalysis = makeEvidenceAnalysis(evidence, processId, criterion, requirements, formalProcesses);
  const evidenceSufficiency = buildEvidenceSufficiency(evidenceAnalysis, requirements);
  const crossProcessAnalysis = buildCrossProcessAnalysis(processId, evidence, formalProcesses);
  const evidenceCappedRating = ratingCappedByEvidence(evidenceScoreRating(evidenceSufficiency, evidenceAnalysis), evidenceSufficiency);
  const helixBlockers = evidenceAnalysis.reduce((sum, item) => sum + Number(item.helixStatusCounts?.blocked || 0), 0);
  const rating = helixBlockers && RATING_SCORE[evidenceCappedRating] > RATING_SCORE["P+"] ? "P+" : evidenceCappedRating;
  const firstEvidence = evidenceAnalysis[0];
  const missingText = evidenceSufficiency.missingTypes.slice(0, 2).join("、") || "跨周期一致性样本";
  const professionalBasis = firstEvidence
    ? `已引用 ${firstEvidence.evidenceCode}《${firstEvidence.source}》，其${firstEvidence.strength === "index-only" ? "文件索引只能间接" : firstEvidence.helixTable ? `Helix 行级表格证据（${firstEvidence.locator}）可以直接` : "正文摘录可以直接"}支持“${criterion}”的判断。`
    : `当前没有可定位到 ${processId} 的项目证据，不能把流程定义或口头说明当作实施证明。`;
  const coveredRelations = crossProcessAnalysis.filter(item => item.evidenceCodes.length).length;
  const blockerText = helixBlockers ? ` Helix 状态字段中发现 ${helixBlockers} 条阻塞对象，未验证关闭前评分上限为 P+。` : "";
  const reason = `${professionalBasis} AI 同时沿上游、下游及 MAN.3/SUP.1/SUP.8～10 检查了 ${crossProcessAnalysis.length} 条过程关系，其中 ${coveredRelations} 条发现关联证据；关联证据仅用于一致性佐证。${blockerText}当前目标过程直接证据覆盖率 ${evidenceSufficiency.coverage}%，仍${evidenceSufficiency.status === "sufficient" ? "需通过访谈确认样本代表性和跨版本稳定性" : `缺少${missingText}`}，因此给出 ${rating} 候选；若补证据后结论变化，应保留重评版本。`;
  const refs = evidenceAnalysis.length
    ? evidenceAnalysis.map(item => `${item.evidenceCode} · ${item.source} · ${item.locator}`)
    : [`未提供 ${processId} / ${canonicalCode(code)} 的可定位证据`];
  const closureEvidence = evidenceSufficiency.status === "sufficient"
    ? ["由审核员抽查至少 3 个跨里程碑样本并确认结论一致", "确认引用证据处于获批基线且可由报告反向打开"]
    : evidenceSufficiency.missingTypes.slice(0, 3).map(item => `补充并定位：${item}`);
  const findings = [];
  if (firstEvidence) findings.push({ type: "O", text: `${firstEvidence.evidenceCode} 已登记并与 ${processId} 关联；${firstEvidence.locator}。` });
  if (evidenceSufficiency.status !== "sufficient") findings.push({ type: "W", text: `${processId} ${canonicalCode(code)} 的证据链不充分：${missingText}未被直接证明，当前评分上限受证据护栏限制。` });
  findings.push({ type: "R", text: closureEvidence[0] || "补充受控样本并由评估师复核。" });
  return {
    id: id("asmt"),
    group: `${processId} · ${pa}`,
    process: processId,
    processName,
    kind,
    pa,
    code: canonicalCode(code),
    title,
    criterion,
    rating,
    aiCandidateRating: rating,
    achievementPercent: RATING_SCORE[rating],
    confidence: Math.min(95, evidenceSufficiency.status === "sufficient" ? 80 + evidenceSufficiency.directCount * 3 : evidenceSufficiency.status === "partial" ? 55 + evidenceSufficiency.directCount * 5 : 38),
    scoreBreakdown: makeScoreBreakdown(rating, index, evidenceSufficiency),
    evidenceAnalysis,
    crossProcessAnalysis,
    evidenceSufficiency,
    requiredEvidence: requirements,
    reason,
    findings,
    refs,
    interviewQuestions: [
      `请演示 ${processId} ${canonicalCode(code)} 最近一次实际执行，从输入、责任人到输出和批准。`,
      `当“${title}”发生偏差或变更时，如何通过 MAN.3、SUP.8、SUP.9、SUP.10 识别影响并证明问题已经闭环？`,
      `请从 ${processId} 的一个样本向上游和下游各追踪一次，确认版本、批准状态和语义一致。`
    ],
    closureEvidence,
    reviewerNote: "",
    reviewed: false,
    aiSource: "local-professional-engine"
  };
}
export function buildAssessments(processes, seedOffset = 0, evidence = [], options = {}) {
  const result = [];
  processes.forEach((processId, pIndex) => {
    const proc = PROCESS_CATALOG.find(item => item.id === processId) || { id: processId, zh: processId, bp: 6 };
    const practices = PRACTICE_LIBRARY[processId] || Array.from({ length: proc.bp }, (_, i) => [`BP${i + 1}`, `${proc.zh} 基本实践 ${i + 1}`, "确认活动被定义、执行、受控并具有可定位的项目级客观证据。"]);
    practices.forEach((practice, index) => result.push(buildProfessionalAssessment({ processId, processName: proc.zh, kind: "BP", pa: "PA 1.1", practice, index, pIndex, seedOffset, evidence, formalProcesses: processes })));
    GP_LIBRARY.forEach((practice, index) => result.push(buildProfessionalAssessment({ processId, processName: proc.zh, kind: "GP", pa: index < 6 ? "PA 2.1" : "PA 2.2", practice, index, pIndex, seedOffset, evidence, formalProcesses: processes })));
  });
  return result;
}
export function buildCustomAssessments(audit, scheme) {
  const evidenceCount = Array.isArray(audit?.evidence) ? audit.evidence.length : 0;
  return (scheme?.questions || []).map((q, index) => {
    // v6.6: no rotating ratings. Candidate derives from how many evidence
    // items are bound to the audit and whether they carry locatable text.
    const locatable = (audit?.evidence || []).filter(item => String(item.content || "").trim().length >= 120 || (item.tables || []).some(table => table.rowCount > 0)).length;
    const rating = !evidenceCount ? "N" : locatable >= 3 ? "L" : locatable >= 1 ? "P+" : "P";
    return {
      id: id("ca"),
      group: q.category || "未分类",
      process: "CUSTOM",
      code: `Q${index + 1}`,
      title: q.text,
      criterion: q.reference || "依据审核方案判断",
      rating,
      confidence: evidenceCount ? Math.min(90, 62 + locatable * 6) : 34,
      reason: !evidenceCount
        ? "当前审核尚未绑定可定位证据，按证据护栏给出 N 候选；请补充能证明执行、责任、时间和结果的受控记录。"
        : locatable
          ? `已发现 ${locatable} 份可定位证据，证据链可用于支持当前判断候选；仍需评估师核实版本、批准和关闭状态。`
          : "已登记证据索引，但未保留可定位正文；按证据护栏限制评分上限，请打开原文核实。",
      findings: !evidenceCount
        ? [{ type: "W", text: "没有可引用的客观证据，不能形成可复核结论。" }, { type: "R", text: "补充并定位至少一份可验证的受控记录。" }]
        : locatable
          ? [{ type: "O", text: "已发现可定位证据，当前结论为候选，需人工复核。" }]
          : [{ type: "W", text: "证据仅保留索引或元数据，无法证明执行事实。" }, { type: "R", text: "打开原文补充引用片段和定位。" }],
      refs: audit.evidence.length ? audit.evidence.slice(0, 3).map(item => item.name) : ["尚未绑定证据"],
      reviewed: false
    };
  });
}
export function buildExecutiveOpinion(project) {
  if (project.aiOpinion) return project.aiOpinion;
  const assessments = project.assessments || [];
  if (!assessments.length) return "尚无评估结果。";
  const weak = assessments.filter(a => RATING_SCORE[a.rating] < 50).length;
  const avg = averageRating(assessments);
  const processText = project.processes ? project.processes.join("、") : "当前范围";
  return `当前 ${processText} 综合评分候选为 ${avg}，识别 ${weak} 个 P 或以下弱项。证据对过程定义的支持通常高于对项目级连续执行的支持；正式结论前应抽查关键样本的版本、批准、双向追溯和问题闭环。`;
}
export function initializeProjectModel(project) {
  project.participants ||= [{ id: "P-LA", name: project.owner || "Maple Mock", short: "MM", role: "Lead Assessor", email: "" }];
  project.workspaces ||= [{ id: "WS-MAIN", name: "主审核员工作区", description: "独立评估记录", final: false }, { id: "WS-FINAL", name: "Consolidated / 已定稿", description: "正式记录", final: true }];
  project.instances ||= [{ id: "INS-1", name: project.product || "Main Project", short: "MAIN", processes: [...(project.processes || [])] }];
  project.attributes ||= { assessmentClass: "Class 2", purpose: "Process Improvement", independence: "Category B", processContext: "Entire Product / Delivery", asil: "QM", disciplines: ["System", "Software"], distributed: "No", supplyChain: "Tier 1", standards: [] };
  project.sessions ||= [];
  project.records ||= [];
  project.notepads ||= [];
  project.guidelines ||= [];
  project.traceLinks ||= [];
  project.planCards = Array.isArray(project.planCards) ? project.planCards : [];
  project.sessions.forEach((session, index) => { session.status ||= "scheduled"; session.order ??= index; });
  project.logs ||= [{ id: id("log"), date: project.date || new Date().toISOString(), action: "Open", user: project.owner || "Maple Mock", comment: "评估已创建" }];
  project.assessmentState ||= "Open";
  project.activeWorkspaceId ||= project.workspaces[0].id;
  project.activeInstanceId ||= project.instances[0].id;
  return project;
}

// ---------------------------------------------------------------------------
// Report generation (backend side)
// ---------------------------------------------------------------------------
export function reportRatingMarkup(rating, withScore = true) {
  return `<span class="report-rating ${ratingClass(rating)}">${esc(rating)}${withScore ? ` · ${RATING_SCORE[rating] || 0}` : ""}</span>`;
}
export function reportSheet(project, label, body, className = "") {
  return `<section class="report-sheet ${className}" data-report-sheet="${esc(label)}"><div class="report-running-head"><strong>Process Evaluation · Explanations &amp; Findings</strong><span>ID.-No.: ${esc(project.reportNo)}</span></div>${body}<div class="report-running-foot">© ${new Date().getFullYear()} AuditFlow AI v${VERSION} · ${esc(label)} <span>后端引擎生成 · AI 初评 + 人工复核</span></div></section>`;
}
export function capabilityChartMarkup(project) {
  return `<div class="capability-bars">${project.processes.map(processId => {
    const level = processCapability(project, processId);
    return `<div class="capability-bar"><strong>${level}</strong><i style="height:${level ? level * 42 : 4}%"></i><span>${esc(processId)}</span></div>`;
  }).join("")}</div>`;
}
export function processRiskTable(project) {
  return `<table class="official-table"><thead><tr><th>Process Area</th><th>Level</th><th>PA1.1</th><th>PA2.1</th><th>PA2.2</th><th>Evidence</th></tr></thead><tbody>${project.processes.map(processId => {
    const items = processAssessments(project, processId);
    const coverage = items.length ? Math.round(items.reduce((s, a) => s + (a.evidenceSufficiency?.coverage || 0), 0) / items.length) : 0;
    return `<tr><td>${esc(processReportName(processId))}</td><td><strong>Level ${processCapability(project, processId)}</strong></td><td>${reportRatingMarkup(processPaRating(project, processId, "PA 1.1"))}</td><td>${reportRatingMarkup(processPaRating(project, processId, "PA 2.1"))}</td><td>${reportRatingMarkup(processPaRating(project, processId, "PA 2.2"))}</td><td>${coverage}%</td></tr>`;
  }).join("")}</tbody></table>`;
}
export function assessmentMatrixMarkup(project) {
  const bpCodes = Array.from({ length: Math.max(1, ...project.processes.map(p => processAssessments(project, p, "PA 1.1").length)) }, (_, i) => `BP${i + 1}`);
  const gpCodes = GP_LIBRARY.map(g => canonicalCode(g[0]));
  const columns = bpCodes.concat(["PA1.1"], gpCodes.slice(0, 6), ["PA2.1"], gpCodes.slice(6), ["PA2.2"]).flat();
  return `<div class="matrix-scroll"><table class="rating-matrix"><thead><tr><th>Process</th>${columns.map(c => `<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>${project.processes.map(processId => `<tr><th>${esc(processId)}</th>${columns.map(code => {
    if (code.startsWith("PA")) return `<td>${reportRatingMarkup(processPaRating(project, processId, code.replace(/^PA/, "PA ")), false)}</td>`;
    const item = processAssessments(project, processId).find(a => a.code === code);
    return `<td>${item ? reportRatingMarkup(item.rating, false) : "–"}</td>`;
  }).join("")}</tr>`).join("")}</tbody></table></div>`;
}
export function reportAssessmentEntry(a) {
  const breakdown = Object.entries(a.scoreBreakdown || {}).map(([key, value]) => `${({ definition: "定义", implementation: "实施", consistency: "一致性", governance: "受控", closure: "闭环" })[key] || key} ${clampScore(value)}`).join(" · ");
  return `<article class="report-assessment-entry"><h4>${reportRatingMarkup(a.rating, false)} ${esc(a.process)}.${esc(a.code)}: ${esc(a.title)} ${a.reviewed ? `<span class="reviewed-mark">人工已复核</span>` : `<span class="draft-mark">待人工复核</span>`}</h4>${(a.targetIndicators || []).length ? `<div class="indicator-target-line"><strong>Candidate indicator mapping / 候选指标映射：</strong>${(a.targetIndicators || []).map(value => `<span class="code-tag">${esc(value)}</span>`).join(" ")}<small> · ${esc(a.mappingStatus || "须由评估师确认")}</small></div>` : ""}${a.governance?.owner ? `<div class="indicator-target-line"><strong>Governance / 治理：</strong>${esc(a.priority || "P2")} · Owner ${esc(a.governance.owner)} · Due ${esc(a.governance.due || "—")} · ${a.governance.assignment === "proposed" ? "建议值，待项目基线确认" : "已确认"}</div>` : ""}<div class="ai-score-line"><strong>AI 候选 ${esc(a.aiCandidateRating || a.rating)} / 人工结论 ${esc(a.rating)}：</strong>${esc(breakdown)} · 把握度 ${a.confidence}% · ${esc(sufficiencyLabel(a.evidenceSufficiency?.status))} ${a.evidenceSufficiency?.coverage || 0}%</div><p>${esc(a.reason)}</p>${(a.findings || []).map(f => `<div class="owr-line"><b>${f.type}</b>${esc(f.text)}</div>`).join("")}<div class="evidence-basis"><strong>Evidence basis / 证据依据</strong>${(a.evidenceAnalysis || []).length ? (a.evidenceAnalysis || []).map(e => `<div class="report-evidence-row"><b>[${esc(e.evidenceCode)}]</b> ${esc(e.source)} · ${esc(e.locator)} · ${esc(e.strength)}<br><small>${esc(e.originProcess || a.process)} → ${esc(e.targetProcess || a.process)} · ${esc(relationLabel(e.relationType || "direct"))}${e.scopeStatus === "related-only" ? " · 关联观察不评级" : ""}<br>${esc(e.excerpt)}</small></div>`).join("") : `<div class="report-evidence-row">无可定位证据；评分受护栏限制。</div>`}<div><strong>缺口 / 最小关闭证据：</strong>${esc((a.closureEvidence || []).join("；") || "由评估师补充确认")}</div>${a.reviewerNote ? `<div><strong>人工复核意见：</strong>${esc(a.reviewerNote)}</div>` : ""}</div></article>`;
}
export function processDetailedReport(project, processId, index) {
  const bp = processAssessments(project, processId, "PA 1.1");
  const gp21 = processAssessments(project, processId, "PA 2.1");
  const gp22 = processAssessments(project, processId, "PA 2.2");
  return reportSheet(project, `Detailed Results · ${processId}`, `<h2 class="report-section-title">3.${index + 1} ${esc(processReportName(processId))} <small>Capability Level ${processCapability(project, processId)}</small></h2><h3>BP Rating Table</h3><table class="bp-rating-table"><tr><th>Result</th>${bp.map(a => `<th>${esc(a.code)}</th>`).join("")}</tr><tr><td>${reportRatingMarkup(processPaRating(project, processId, "PA 1.1"))}</td>${bp.map(a => `<td>${reportRatingMarkup(a.rating)}</td>`).join("")}</tr></table><h3>Capability Attribute Rating Table</h3><table class="official-table"><thead><tr><th>PA</th><th>Generic Practices</th><th>Result</th></tr></thead><tbody><tr><td>PA1.1 Process Performance</td><td>BP1–BP${bp.length}</td><td>${reportRatingMarkup(processPaRating(project, processId, "PA 1.1"))}</td></tr><tr><td>PA2.1 Performance Management</td><td>${gp21.map(a => `${a.code}: ${a.rating}`).join(" · ")}</td><td>${reportRatingMarkup(processPaRating(project, processId, "PA 2.1"))}</td></tr><tr><td>PA2.2 Work Product Management</td><td>${gp22.map(a => `${a.code}: ${a.rating}`).join(" · ")}</td><td>${reportRatingMarkup(processPaRating(project, processId, "PA 2.2"))}</td></tr></tbody></table><h3>Level 1 Results</h3>${bp.map(reportAssessmentEntry).join("")}<h3>Level 2 Results</h3>${gp21.concat(gp22).map(reportAssessmentEntry).join("")}`, "detail-sheet");
}
export function crossProcessReportMarkup(project) {
  const method = reportSheet(project, "Cross-Process Analysis Method", `<h2 class="report-section-title">2.4 Cross-Process Analysis / 跨过程分析</h2><p>AI 对每份证据先在本地读取正文、表格和 Helix 对象字段，识别主过程及稳定行定位，再执行四遍关系扫描。范围内过程进入 BP/GP 正式评分；范围外过程仅形成“关联观察·不评级”。关联证据可以证明接口一致性，但不能替代目标过程的直接实施证据。</p><table class="official-table"><thead><tr><th>Pass</th><th>分析问题</th></tr></thead><tbody>${CROSS_PROCESS_PASSES.map((item, index) => `<tr><td>${index + 1}. ${esc(item[1])}</td><td>${esc(item[2])}</td></tr>`).join("")}</tbody></table><div class="report-disclaimer">关系模型重点覆盖需求—设计—实现—验证价值链，以及 MAN.3 项目接口和计划、SUP.1 质量保证、SUP.8 配置完整性、SUP.9 问题闭环、SUP.10 变更影响与双向追溯。Helix 表格按 ID、状态、责任、版本/基线、上下游链接、影响与关闭字段联合判断；仅有链接或 Closed 状态不会自动证明闭环有效。</div>`);
  const details = project.processes.map((processId, index) => {
    const rows = visibleCrossRows(project, processId);
    return reportSheet(project, `Cross-Process · ${processId}`, `<h2 class="report-section-title">2.4.${index + 1} ${esc(processName(processId))} 关系分析</h2><table class="official-table cross-process-report-table"><thead><tr><th>接口</th><th>关系 / 范围</th><th>分析遍次</th><th>证据</th><th>AI 分析过程</th><th>风险与跟进</th></tr></thead><tbody>${rows.map(row => `<tr><td>${esc(row.sourceProcess)} → ${esc(row.targetProcess)}</td><td>${esc(relationLabel(row.relationType))}<br><small>${row.scopeStatus === "in-scope" ? "正式范围" : "关联观察·不评级"}</small></td><td>${row.analysisPasses.map(pass => esc(CROSS_PROCESS_PASSES.find(item => item[0] === pass)?.[1] || pass)).join("；")}</td><td>${row.evidenceCodes.map(code => `[${esc(code)}]`).join(" ") || "未覆盖"}</td><td>${esc(row.supportedClaim)}<br><small>${esc(row.gapOrRisk)}</small></td><td>${esc(row.followUp)}</td></tr>`).join("")}</tbody></table>`);
  }).join("");
  return method + details;
}
export function traceabilityReportMarkup(project) {
  const coverage = traceCoverage(project);
  return reportSheet(project, "Indicator–Evidence Trace Matrix", `<h2 class="report-section-title">2.5 Indicator–Evidence Trace Matrix / 指标—证据追溯矩阵</h2><p>矩阵记录 AI 推断和评估师人工确认的 BP/GP—证据关系。Direct 只表示证据属于目标过程且存在可定位正文或表格；Corroborating 仅用于核实上下游接口、MAN.3、SUP.1、SUP.8、SUP.9 或 SUP.10 的一致性与闭环，不替代目标过程实施证据。</p><div class="report-risk-grid"><div><span>指标有关系</span><strong>${coverage.linked}/${coverage.total}</strong></div><div><span>直接覆盖</span><strong>${coverage.directPercent}%</strong></div><div><span>人工确认</span><strong>${coverage.confirmed}</strong></div><div><span>无关系缺口</span><strong>${coverage.gaps}</strong></div></div><table class="official-table trace-report-matrix"><thead><tr><th>Indicator</th><th>AI / Human rating</th><th>Direct evidence</th><th>Corroborating / related</th><th>Assessor-confirmed</th><th>Gap, risk &amp; next evidence</th></tr></thead><tbody>${project.assessments.map(assessment => {
    const links = traceLinksForAssessment(project, assessment);
    const direct = links.filter(link => link.strength === "direct");
    const related = links.filter(link => link.strength !== "direct");
    const confirmed = links.filter(link => link.confirmed);
    const cite = items => items.map(link => `<b>[${esc(link.evidenceCode || "EV")}]</b> ${esc(link.locator || "待定位")}`).join("<br>") || "—";
    return `<tr><td><strong>${esc(indicatorKey(assessment))}</strong><br><small>${esc(assessment.title)}</small></td><td>${reportRatingMarkup(assessment.aiCandidateRating || assessment.rating, false)} / ${reportRatingMarkup(assessment.rating, false)}<br><small>${assessment.reviewed ? "人工已复核" : "待人工复核"}</small></td><td>${cite(direct)}</td><td>${cite(related)}</td><td>${confirmed.length ? confirmed.map(link => `[${esc(link.evidenceCode || "EV")}] ${esc(link.creator || "Assessor")}`).join("<br>") : "—"}</td><td>${esc((assessment.evidenceSufficiency?.missingTypes || []).join("；") || (assessment.closureEvidence || []).slice(0, 2).join("；") || "需确认代表性与跨版本稳定性")}</td></tr>`;
  }).join("")}</tbody></table><div class="report-disclaimer">AI 分析过程：证据解析 → 主过程识别 → BP/GP 适配 → direct / corroborating / index-only 分类 → 上下游与治理支撑过程四遍扫描 → 证据充分性限分 → 评估师确认关系和最终评分。人工确认关系不会自动提高评分，也不会把范围外过程纳入正式评级。</div>`);
}
export function actionPlanAppendixMarkup(project) {
  const issues = project.actionPlanIssues || [];
  if (!issues.length) return "";
  const severityCount = severity => issues.filter(item => String(item.severity).toLowerCase() === severity.toLowerCase()).length;
  const missingOwners = issues.filter(item => !item.owner || item.owner === "—").length;
  const missingDue = issues.filter(item => !item.due || item.due === "—").length;
  const row = issue => `<tr><td>${esc(issue.issue)}</td><td>${esc(issue.process)}</td><td>${esc((issue.targetIndicators || []).join("、") || "待确认")}<br><small>${esc(issue.mappingStatus || "")}</small></td><td>${esc(issue.theme || "—")}</td><td>${esc(issue.priority || "P2")} / ${esc(issue.severity || "待确认")}</td><td>${esc(issue.auditExplanation || issue.originalProblem || "—")}<br><small>${esc(issue.risk || "—")}</small></td><td>${esc((issue.closureEvidence || []).join("；") || "待评估师定义")}<br><small>${esc(issue.closureRule || "")}</small></td><td>${esc(issue.owner || "—")} / ${esc(issue.due || "—")}<br><small>建议值，待项目基线确认</small></td></tr>`;
  return reportSheet(project, "CEP Action Plan Appendix", `<h2 class="report-section-title">7. CEP Action Plan Issue Register / 整改问题清单</h2><div class="report-disclaimer">本附录来自 ${esc(project.actionPlanSourceFile || "CEP Action Plan")}。Action Plan、评估纪要和 OPL 记录属于评估输入或佐证，能够说明问题被识别，但不能替代目标过程的直接实施证据，也不能单独证明整改已经关闭。关闭应同时证明：组织标准已更新、项目已采用、结果已评审、问题已验证关闭。</div><div class="report-risk-grid"><div><span>Open issues</span><strong>${issues.length}</strong></div><div><span>Major / Minor</span><strong>${severityCount("Major")} / ${severityCount("Minor")}</strong></div><div><span>Owner missing</span><strong>${missingOwners}</strong></div><div><span>Due missing</span><strong>${missingDue}</strong></div></div><table class="official-table"><thead><tr><th>Issue</th><th>Source process</th><th>Candidate indicators</th><th>Work product / Topic</th><th>Priority / Severity</th><th>Assessment opinion / Risk</th><th>Minimum closure evidence / Rule</th><th>Owner / Due</th></tr></thead><tbody>${issues.map(row).join("")}</tbody></table><div class="report-disclaimer">证据护栏：Direct 证据必须可定位到受控项目工作产品；Corroborating 证据只用于支持接口、依赖、一致性或闭环；Index-only 只能证明文件或记录存在。相关过程证据不能替代目标过程直接证据，AI 输出为候选结论，须由评估师复核。</div>`);
}
export function formalReportMarkup(project) {
  refreshProjectOutcome(project);
  const quality = assessmentQuality(project);
  const final = project.importSource ? project.status === "complete" : project.assessmentState === "Closed" && quality.ready;
  const weak = project.assessments.filter(a => RATING_SCORE[a.rating] < 50);
  const reviewed = Math.round(project.assessments.filter(a => a.reviewed).length / Math.max(1, project.assessments.length) * 100);
  const cover = reportSheet(project, "Cover", `<div class="report-status-stamp ${final ? "final" : ""}">${final ? "FINAL / 已定稿" : "CONTROLLED DRAFT / 受控草稿"}</div><p class="report-blue-label">Automotive SPICE Process Assessment</p><h1 class="report-title">${esc(project.organization)}<br>过程评估报告</h1><p class="report-subtitle">${esc(project.name)} · ${esc(project.product)}</p><table class="official-table report-cover-table"><tbody>${[["Company", project.organization, "Project", project.name], ["Product", project.product, "PAM Version", project.pam], ["Target / Achieved Level", `${project.targetLevel} / ${project.achievedLevel}`, "Assessment Date", formatDate(project.date)], ["Report No.", project.reportNo, "Class / Type / Category", `${project.attributes?.assessmentClass || "Class 2"} / Process Assessment / AI 辅助评估`], ["Lead Assessor", project.owner, "Assessors", (project.participants || []).map(p => p.name).join("、") || project.owner]].map(row => `<tr>${row.map((cell, i) => `<${i % 2 === 0 ? "th" : "td"}>${esc(cell)}</${i % 2 === 0 ? "th" : "td"}>`).join("")}</tr>`).join("")}</tbody></table><h2>Assessment Scope and Capability Level</h2>${capabilityChartMarkup(project)}<div class="report-signatures"><div>Lead Assessor</div><div>Project Representative</div><div>Quality Representative</div></div>`, "cover-sheet");
    const tocRow = (no, title, target) => `<tr><td>${no}</td><td>${title}</td><td class="toc-page" data-toc-target="${esc(target)}">—</td></tr>`;
  const contents = reportSheet(project, "Contents / Background", `<h2 class="report-section-title">Contents</h2><table class="toc-table"><thead><tr><th>No.</th><th>Section</th><th>Page</th></tr></thead><tbody>${tocRow("1","Background","Contents / Background")}${tocRow("2","Summary","Summary")}${tocRow("2.1","Management Summary","Summary")}${tocRow("2.2","Assumptions &amp; Constraints","Summary")}${tocRow("2.3","Risk Dashboard","Summary")}${tocRow("2.4","Cross-Process Analysis Method &amp; Results","Cross-Process Analysis Method")}${tocRow("2.5","Indicator–Evidence Trace Matrix","Indicator–Evidence Trace Matrix")}${tocRow("2.6","BP / PA / GP 评级矩阵","BP / PA / GP Matrix")}${tocRow("3","Detailed Results",`Detailed Results · ${project.processes[0]||""}`)}${project.processes.map((p, i) => tocRow(`3.${i+1}`, processReportName(p), `Detailed Results · ${p}`)).join("")}${tocRow("4","Assessed Work Products","Work Products / Final Remark")}${tocRow("5","Findings &amp; Improvement Roadmap","Work Products / Final Remark")}${tocRow("6","Final Remark","Work Products / Final Remark")}${project.actionPlanIssues?.length ? tocRow("7","CEP Action Plan Issue Register","CEP Action Plan Appendix") : ""}</tbody></table><h2 class="report-section-title">1. Background</h2><table class="official-table"><tbody>${[["Assessment Date", formatDate(project.date)], ["Company", project.organization], ["Project / Product", `${project.name} / ${project.product}`], ["Assessment Team", (project.participants || []).map(p => `${p.name}（${p.role}）`).join("、")], ["PAM Version", project.pam], ["Assessment Class", project.attributes?.assessmentClass || "Class 2"], ["Target / Achieved Level", `${project.targetLevel} / ${project.achievedLevel}`], ["Formal Assessment Scope", project.processes.map(processReportName).join("、")], ["Related Context", "上游、下游、MAN.3、SUP.1、SUP.8、SUP.9、SUP.10（范围外不评级）"], ["Objective", "评估所选过程在 Automotive SPICE 下的过程能力，并沿过程接口识别风险、证据缺口与最小改进闭环。"]].map(row => `<tr><th>${esc(row[0])}</th><td>${esc(row[1])}</td></tr>`).join("")}</tbody></table>`);
  const summary = reportSheet(project, "Summary", `<h2 class="report-section-title">2. Summary</h2>${project.importSource ? `<div class="report-disclaimer"><strong>Imported professional assessment:</strong> ${esc(project.importSource.sourceFile)} · ${esc(project.importSource.reportVersion)} · ${esc(project.importSource.assessmentPeriod)}. Progress 100% means the assessment activity and import are complete; it does not mean all ASPICE processes achieved the target capability level.</div>` : ""}<h3>2.1 Management Summary</h3><p>${esc(buildExecutiveOpinion(project))}</p><div class="report-risk-grid"><div><span>Achieved Level</span><strong>${esc(project.achievedLevel)}</strong></div><div><span>Weakness candidate</span><strong>${weak.length}</strong></div><div><span>Evidence coverage</span><strong>${quality.coverage}%</strong></div><div><span>Human review</span><strong>${reviewed}%</strong></div></div><h3>2.2 Assumptions &amp; Constraints</h3><ul><li>AI 仅基于当前登记且与过程范围关联的证据生成候选结论。</li><li>仅文件名或元数据命中的证据不会被当作项目实施的直接证明。</li><li>未复核、证据不足或记录未定稿的条目不会通过关闭质量门禁。</li></ul><h3>2.3 Risk Dashboard</h3>${processRiskTable(project)}`);
  
  const matrix = reportSheet(project, "BP / PA / GP Matrix", `<h2 class="report-section-title">BP / PA / GP 评级矩阵</h2>${assessmentMatrixMarkup(project)}<div class="rating-legend report-legend">${RATING_ORDER.map(r => `<div>${reportRatingMarkup(r)}</div>`).join("")}</div>`);const crossProcess = crossProcessReportMarkup(project);
  const traceability = traceabilityReportMarkup(project);
  const details = project.processes.map((processId, index) => processDetailedReport(project, processId, index)).join("");
  const workProducts = reportSheet(project, "Work Products / Final Remark", `<h2 class="report-section-title">4. Assessed Work Products</h2><table class="official-table"><thead><tr><th>No.</th><th>ID</th><th>Primary Process</th><th>Related Context</th><th>Name / Structure</th><th>Helix Table Readout</th><th>Reference quality</th></tr></thead><tbody>${project.evidence.map((e, index) => {
    const primary = inferEvidencePrimaryProcesses(e, project.processes);
    const related = [...new Set(primary.flatMap(processId => relatedProcessesFor(processId, project.processes).map(row => row.relatedProcess)))].filter(p=>(project.processes||[]).includes(p));
    const locatable = String(e.content || "").trim().length >= 120 || (e.tables || []).some(table => table.rowCount);
    return `<tr><td>${index + 1}</td><td>${esc(e.code || `EV.${String(index + 1).padStart(3, "0")}`)}</td><td>${esc(primary.join("、") || e.scope || "未识别")}</td><td>${esc(related.join("、") || "—")}</td><td>${esc(e.name)}<br><small>${esc(e.structure || e.source || "本地上传")}</small></td><td>${e.helix?.detected ? `${e.helix.tableCount} 表 / ${e.helix.rowCount} 行 / ${e.helix.linkedRows} 关系行<br><small>${esc((e.helix.fields || []).join("、"))}</small>` : "—"}</td><td>${locatable ? "Locatable text/table / 可定位正文或表格" : "Metadata only / 待定位"}</td></tr>`;
  }).join("")}</tbody></table><h2 class="report-section-title">5. Findings &amp; Improvement Roadmap</h2><table class="official-table"><thead><tr><th>Priority</th><th>Indicator</th><th>Weakness / Risk</th><th>Minimum closure evidence</th><th>Owner / Due</th></tr></thead><tbody>${project.assessments.filter(a => (a.findings || []).some(f => f.type === "W")).slice(0, 30).map((a, index) => `<tr><td>${index < 5 ? "P1" : "P2"}</td><td>${esc(indicatorKey(a))}</td><td>${esc(a.findings.find(f => f.type === "W")?.text || a.reason)}</td><td>${esc((a.closureEvidence || []).join("；"))}</td><td>待分配</td></tr>`).join("") || `<tr><td colspan="5">当前没有弱项候选。</td></tr>`}</tbody></table><h2 class="report-section-title">6. Final Remark</h2><div class="report-disclaimer">本报告由 AuditFlow AI v${VERSION} 后端引擎生成，逐项评级包含 AI 初评、本地 Office/PDF 与 Helix 表格解析、直接证据充分性护栏、跨过程四遍分析和人工复核状态，供内部过程改进与能力提升参考。范围外关联过程只形成观察，不构成正式评级；跨过程证据不能替代目标过程直接证据。若需作为正式评估或认证结论，应由具备适用资质、权限与独立性的评估师基于完整证据复核确认。${final ? "当前版本已通过本工具的内部质量门禁。" : "当前版本仍为受控草稿，存在未复核或证据充分性缺口。"}</div>`);
  const actionPlanAppendix = actionPlanAppendixMarkup(project);
  return cover + contents + summary + matrix + crossProcess + traceability + details + workProducts + actionPlanAppendix;
}

const WORD_CSS = `@page{size:A4;margin:15mm}body{font-family:Arial,'Microsoft YaHei',sans-serif;color:#1b2738;margin:0;font-size:10pt}.report-sheet{page-break-after:always;padding:8mm 4mm;position:relative}.report-running-head{font-size:8pt;color:#526071;border-bottom:1px solid #9eabb8;padding-bottom:4mm;margin-bottom:7mm}.report-running-head span{float:right}.report-running-foot{font-size:8pt;color:#687586;border-top:1px solid #cbd2d9;padding-top:3mm;margin-top:8mm}.report-title{font-size:29pt;line-height:1.15;margin:10mm 0 4mm}.report-subtitle{font-size:12pt;color:#536071}.official-table,.rating-matrix,.bp-rating-table{width:100%;border-collapse:collapse;margin:4mm 0;font-size:8.5pt}.official-table th,.official-table td,.rating-matrix th,.rating-matrix td,.bp-rating-table th,.bp-rating-table td{border:1px solid #c5ced8;padding:2.3mm;vertical-align:top}.official-table th,.rating-matrix th,.bp-rating-table th{background:#eef1f4}.report-section-title{font-size:16pt;margin:7mm 0 3mm}.report-assessment-entry{border-top:1px solid #d8dee5;padding:4mm 0}.report-assessment-entry h4{margin:0 0 2mm;font-size:10pt}.report-rating{display:inline-block;border:1px solid #6aa88d;background:#e6faed;padding:1mm 2.5mm;margin-right:2mm}.report-rating.warn{border-color:#e6bd55;background:#fff5d9}.report-rating.danger{border-color:#e58b86;background:#fff0ef}.owr-line{margin:1.4mm 0}.owr-line b{display:inline-block;width:5mm;color:#225ee8}.evidence-basis{background:#f5f7f9;border-left:3px solid #2d66e8;padding:3mm;margin:2mm 0}.report-signatures{display:table;width:100%;margin-top:18mm}.report-signatures div{display:table-cell;width:33%;border-top:1px solid #929eaa;padding-top:2mm}.report-status-stamp{float:right;border:2px solid #d69b26;color:#a76d00;padding:2mm 4mm;font-weight:bold}.report-status-stamp.final{border-color:#2f8b66;color:#216b50}.capability-bars{display:table;width:100%;height:55mm;border-bottom:1px solid #8895a3}.capability-bar{display:table-cell;text-align:center;vertical-align:bottom}.capability-bar i{display:block;background:#2e66e7;width:45%;margin:auto}.capability-bar strong,.capability-bar span{display:block}.report-risk-grid{display:table;width:100%;margin:4mm 0}.report-risk-grid div{display:table-cell;border:1px solid #ccd4dc;padding:3mm}.report-evidence-row{margin:1.5mm 0}.report-disclaimer{margin-top:8mm;padding:4mm;background:#f1f4f7;border:1px solid #d1d8df}.matrix-scroll{overflow:visible}.toc-table{width:100%;border-collapse:collapse;font-size:9.5pt}.toc-table td{border-bottom:1px solid #e2e7ec;padding:1.5mm 2mm}.reviewed-mark{color:#217a55;font-weight:normal;font-size:8pt}.draft-mark{color:#a76d00;font-weight:normal;font-size:8pt}.code-tag{display:inline-block;background:#edf3fa;border:1px solid #c7d6e8;border-radius:3px;padding:0 1.5mm;font-size:7.5pt;margin-right:1mm}.indicator-target-line{margin:1mm 0}.ai-score-line{margin:1.5mm 0}`;

export function buildWordReport(project, type = "standard") {
  refreshProjectOutcome(project);
  if (type === "standard") {
    let reportHtml = formalReportMarkup(project);
    // v6.7: real Word TOC field so Word can generate/refresh a TOC with page
    // numbers (select all, then F9). Heading outline levels make h2/h3 the
    // TOC entries.
    reportHtml = reportHtml
      .replace(/<h2 class="report-section-title">/g, '<h2 class="report-section-title" style="mso-outline-level:2">')
      .replace(/<h3>/g, '<h3 style="mso-outline-level:3">')
      .replace(/<table class="toc-table">[\s\S]*?<\/table>/, '<div style="font-size:9pt;color:#687586;margin-bottom:6mm">目录：在 Word 中打开后全选（Ctrl+A）并按 F9，自动生成或刷新带页码的目录。</div><div style="mso-element:field-begin"></div><span style="mso-spacerun:yes">&nbsp;</span>TOC \\o "1-2" \\h \\z \\u <div style="mso-element:field-end"></div>');
    return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(project.name)}</title><style>${WORD_CSS}</style></head><body>${reportHtml}</body></html>`;
  }
  const meta = `受审对象：${project.organization}`;
  const body = `<div class="meta">${esc(meta)}<br>日期：${formatDate(project.date)}　负责人：${esc(project.owner)}</div><h2>AI 与人工复核结果</h2><table><tr><th>审核项</th><th>评分</th><th>结论与理由</th><th>发现</th><th>证据</th></tr>${(project.assessments || []).map(a => `<tr><td><span class="tag">${esc(a.code)}</span> ${esc(a.title)}</td><td>${a.rating}</td><td>${esc(a.reason)}</td><td>${a.findings.map(f => `<b>${f.type}</b> ${esc(f.text)}`).join("<br>")}</td><td>${esc(a.refs.join("；"))}</td></tr>`).join("")}</table><p><small>声明：AI 提供初评候选，正式结论由评估师人工确认。</small></p>`;
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(project.name)}</title><style>body{font-family:Arial,'Microsoft YaHei',sans-serif;margin:40px;color:#19323e}h1{color:#0b6f69}table{width:100%;border-collapse:collapse;font-size:11px}th,td{border:1px solid #ccd7db;padding:8px;text-align:left}th{background:#edf5f4}.meta{padding:12px;background:#f2f7f7;margin-bottom:20px}.tag{font-weight:bold;color:#08766f}</style></head><body><h1>${esc(project.name)} · 自定义审核报告</h1>${body}</body></html>`;
}

export function buildVisualDashboard(project) {
  const quality = assessmentQuality(project);
  const coverage = traceCoverage(project);
  const processes = project.processes || [];
  const maxLevel = 2;
  const barW = 52, gap = 18, height = 150;
  const width = Math.max(320, processes.length * (barW + gap) + 24);
  const bars = processes.map((processId, index) => {
    const level = processCapability(project, processId);
    const h = Math.max(6, (level / maxLevel) * (height - 46));
    const x = 14 + index * (barW + gap);
    const y = height - 30 - h;
    const color = level === 2 ? "#0e9488" : level === 1 ? "#f59e0b" : "#e05b5b";
    return `<g><rect x="${x}" y="${y}" width="${barW}" height="${h}" rx="6" fill="${color}"></rect><text x="${x + barW / 2}" y="${y - 6}" text-anchor="middle" font-size="12" font-weight="700" fill="#1b2738">CL${level}</text><text x="${x + barW / 2}" y="${height - 12}" text-anchor="middle" font-size="11" fill="#526071">${esc(processId)}</text></g>`;
  }).join("");
  const counts = { N: 0, P: 0, L: 0, F: 0 };
  (project.assessments || []).forEach(a => {
    const r = a.rating || "N";
    if (r === "F") counts.F++;
    else if (r.startsWith("L")) counts.L++;
    else if (r.startsWith("P")) counts.P++;
    else counts.N++;
  });
  const total = Math.max(1, project.assessments.length);
  const dist = [["N", counts.N, "#e05b5b"], ["P-", counts.P, "#f59e0b"], ["L", counts.L, "#0e9488"], ["F", counts.F, "#2f8b66"]].map(([label, value, color]) => `<div class="dist-row"><span>${label}</span><div class="dist-track"><i style="width:${Math.round(value / total * 100)}%;background:${color}"></i></div><b>${value}</b></div>`).join("");
  const assessments = project.assessments || [];
  return `<section class="v5-dashboard"><div class="v5-kpis"><article><span>综合能力</span><strong>${esc(project.achievedLevel || "—")}</strong></article><article><span>证据覆盖</span><strong>${quality.coverage}%</strong></article><article><span>指标追溯</span><strong>${coverage.linked}/${coverage.total}</strong></article><article><span>人工复核</span><strong>${assessments.filter(a => a.reviewed).length}/${assessments.length}</strong></article><article><span>弱项候选</span><strong>${assessments.filter(a => RATING_SCORE[a.rating] < 50).length}</strong></article></div><div class="v5-charts"><figure><figcaption>过程能力等级（Capability Level）</figcaption><svg viewBox="0 0 ${width} ${height}" role="img" aria-label="过程能力等级柱状图">${bars}</svg></figure><figure><figcaption>评分分布（Rating Distribution）</figcaption><div class="dist-panel">${dist}</div></figure></div></section>`;
}

const VISUAL_CSS = `:root{--af-teal:#0e9488;--af-ink:#1b2738;--af-muted:#526071;--af-line:#d8dee5;--af-bg:#f5f8f9;--af-card:#ffffff;--af-accent:#2e66e7}*{box-sizing:border-box}body{margin:0;font-family:'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif;color:var(--af-ink);background:var(--af-bg);line-height:1.55}.v5-shell{max-width:1060px;margin:0 auto;padding:28px 20px 60px}.v5-masthead{background:linear-gradient(135deg,#0b6f69 0%,#0e9488 58%,#1fa9a0 100%);color:#fff;border-radius:18px;padding:26px 28px;margin-bottom:22px;box-shadow:0 12px 30px rgba(14,148,136,.22)}.v5-masthead h1{margin:0 0 4px;font-size:26px;letter-spacing:.3px}.v5-masthead p{margin:0;opacity:.92;font-size:13px}.v5-masthead .v5-meta{margin-top:14px;display:flex;flex-wrap:wrap;gap:8px}.v5-masthead .v5-meta span{background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.25);border-radius:999px;padding:3px 11px;font-size:11.5px}.v5-dashboard{display:grid;gap:14px;margin:18px 0}.v5-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}.v5-kpis article{background:var(--af-card);border:1px solid var(--af-line);border-radius:14px;padding:14px 16px;box-shadow:0 2px 8px rgba(27,39,56,.04)}.v5-kpis article span{display:block;font-size:11px;color:var(--af-muted);margin-bottom:4px}.v5-kpis article strong{font-size:22px;color:var(--af-teal)}.v5-charts{display:grid;grid-template-columns:1.4fr 1fr;gap:14px}.v5-charts figure{background:var(--af-card);border:1px solid var(--af-line);border-radius:14px;margin:0;padding:14px 16px;box-shadow:0 2px 8px rgba(27,39,56,.04)}.v5-charts figcaption{font-size:12px;font-weight:700;color:var(--af-muted);margin-bottom:8px}.dist-panel{display:grid;gap:8px;padding-top:4px}.dist-row{display:grid;grid-template-columns:28px 1fr 34px;align-items:center;gap:8px;font-size:12px}.dist-track{height:10px;background:#eef1f4;border-radius:999px;overflow:hidden}.dist-track i{display:block;height:100%;border-radius:999px}.v5-summary{background:var(--af-card);border:1px solid var(--af-line);border-radius:14px;padding:18px 20px;margin:14px 0;box-shadow:0 2px 8px rgba(27,39,56,.04)}.v5-summary h2{margin:0 0 8px;font-size:15px;color:var(--af-teal)}.v5-summary p{margin:0;font-size:13px;color:var(--af-ink)}.v5-report{background:var(--af-card);border:1px solid var(--af-line);border-radius:18px;padding:22px 26px;box-shadow:0 4px 16px rgba(27,39,56,.06)}.report-sheet{page-break-after:always;padding:4mm 0}.report-running-head{font-size:8.5pt;color:var(--af-muted);border-bottom:1px solid var(--af-line);padding-bottom:3mm;margin-bottom:6mm}.report-running-head span{float:right}.report-running-foot{font-size:8.5pt;color:var(--af-muted);border-top:1px solid var(--af-line);padding-top:3mm;margin-top:7mm}.report-running-foot span{float:right}.report-title{font-size:28pt;line-height:1.12;margin:9mm 0 3mm}.report-subtitle{font-size:12pt;color:var(--af-muted)}.report-blue-label{color:var(--af-accent);font-size:9pt;letter-spacing:1px;text-transform:uppercase}.official-table,.rating-matrix,.bp-rating-table{width:100%;border-collapse:collapse;margin:3mm 0;font-size:8.6pt}.official-table th,.official-table td,.rating-matrix th,.rating-matrix td,.bp-rating-table th,.bp-rating-table td{border:1px solid #c5ced8;padding:2.2mm;vertical-align:top}.official-table th,.rating-matrix th,.bp-rating-table th{background:#eef1f4}.report-section-title{font-size:16pt;margin:6mm 0 3mm}.report-assessment-entry{border-top:1px solid var(--af-line);padding:3.5mm 0}.report-assessment-entry h4{margin:0 0 2mm;font-size:10pt}.report-rating{display:inline-block;border:1px solid #6aa88d;background:#e6faed;padding:1mm 2.5mm;margin-right:2mm;border-radius:4px;font-size:8.4pt}.report-rating.warn{border-color:#e6bd55;background:#fff5d9}.report-rating.danger{border-color:#e58b86;background:#fff0ef}.owr-line{margin:1.4mm 0}.owr-line b{display:inline-block;width:5mm;color:var(--af-accent)}.evidence-basis{background:#f5f7f9;border-left:3px solid var(--af-accent);padding:3mm;margin:2mm 0;border-radius:0 6px 6px 0}.report-signatures{display:table;width:100%;margin-top:16mm}.report-signatures div{display:table-cell;width:33%;border-top:1px solid #929eaa;padding-top:2mm}.report-status-stamp{float:right;border:2px solid #d69b26;color:#a76d00;padding:2mm 4mm;font-weight:bold;border-radius:6px}.report-status-stamp.final{border-color:#2f8b66;color:#216b50}.capability-bars{display:table;width:100%;height:48mm;border-bottom:1px solid #8895a3}.capability-bar{display:table-cell;text-align:center;vertical-align:bottom}.capability-bar i{display:block;background:var(--af-teal);width:45%;margin:auto;border-radius:4px 4px 0 0}.capability-bar strong,.capability-bar span{display:block}.report-risk-grid{display:table;width:100%;margin:3mm 0}.report-risk-grid div{display:table-cell;border:1px solid #ccd4dc;padding:3mm;text-align:center}.report-evidence-row{margin:1.4mm 0}.report-disclaimer{margin-top:7mm;padding:4mm;background:#f1f4f7;border:1px solid #d1d8df;border-radius:6px;font-size:8.6pt}.matrix-scroll{overflow:auto}.toc-table{width:100%;border-collapse:collapse;font-size:9.5pt}.toc-table td{border-bottom:1px solid #e2e7ec;padding:1.5mm 2mm}.reviewed-mark{color:#217a55;font-weight:normal;font-size:8pt}.draft-mark{color:#a76d00;font-weight:normal;font-size:8pt}.code-tag{display:inline-block;background:#edf3fa;border:1px solid #c7d6e8;border-radius:3px;padding:0 1.5mm;font-size:7.5pt;margin-right:1mm}.indicator-target-line{margin:1mm 0}.ai-score-line{margin:1.5mm 0}@media print{body{background:#fff}.v5-shell{max-width:none;padding:0}.v5-masthead,.v5-dashboard,.v5-summary{box-shadow:none}.v5-report{border:none;padding:0;border-radius:0}}@media (max-width:760px){.v5-charts{grid-template-columns:1fr}.v5-kpis{grid-template-columns:repeat(2,1fr)}}`;

export function buildVisualReport(project, type = "standard") {
  refreshProjectOutcome(project);
  const opinion = buildExecutiveOpinion(project);
  const reportBody = type === "standard" ? formalReportMarkup(project) : "";
  const customBody = type === "custom" ? `<section class="report-sheet"><h2 class="report-section-title">逐题评估结果</h2><table class="official-table"><thead><tr><th>问题</th><th>评分</th><th>结论与理由</th><th>发现</th><th>证据</th></tr></thead><tbody>${(project.assessments || []).map(a => `<tr><td>${esc(a.code)} ${esc(a.title)}</td><td>${reportRatingMarkup(a.rating)}</td><td>${esc(a.reason)}</td><td>${(a.findings || []).map(f => `<b>${f.type}</b> ${esc(f.text)}`).join("<br>")}</td><td>${esc(a.refs.join("；"))}</td></tr>`).join("")}</tbody></table></section>` : "";
  const stamp = project.assessmentState === "Closed" ? "FINAL / 已定稿" : "CONTROLLED DRAFT / 受控草稿";
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(project.name)} · AuditFlow v${VERSION} 可视化报告</title><style>${VISUAL_CSS}</style></head><body><div class="v5-shell"><header class="v5-masthead"><div style="float:right;font-size:11px;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.3);border-radius:999px;padding:3px 10px">${esc(stamp)}</div><h1>${esc(project.organization)} · 过程评估报告</h1><p>${esc(project.name)} · ${esc(project.product)} · 报告编号 ${esc(project.reportNo || "—")}</p><div class="v5-meta"><span>PAM：${esc(project.pam || "—")}</span><span>目标 / 达成：${esc(project.targetLevel || "—")} / ${esc(project.achievedLevel || "—")}</span><span>评估日期：${formatDate(project.date)}</span><span>负责人：${esc(project.owner || "—")}</span><span>生成：AuditFlow v${VERSION} 后端引擎（本机命令行）</span></div></header>${buildVisualDashboard(project)}<section class="v5-summary"><h2>管理层意见</h2><p>${esc(opinion)}</p></section><div class="v5-report">${reportBody}${customBody}</div><footer style="margin-top:18px;font-size:11px;color:var(--af-muted);text-align:center">本报告由 AuditFlow v${VERSION} 后端引擎在本机生成；AI 输出为候选结论，正式结论由评估师人工确认。</footer></div></body></html>`;
}

// ---------------------------------------------------------------------------
// CSV / JSON builders
// ---------------------------------------------------------------------------
function csvCell(value) { return `"${String(value == null ? "" : value).replaceAll('"', '""')}"`; }
export function buildRecordsCsv(project) {
  const lines = ["ID,类型,指标,描述,证据,关闭状态"];
  (project.records || []).forEach(r => {
    const typeLabel = ({ strength: "优势", weakness: "弱项", recommendation: "建议", observation: "观察", comment: "备注", question: "访谈问题" })[r.type] || r.type || "";
    const evidence = (r.evidenceIds || []).map(eid => (project.evidence || []).find(e => e.id === eid)?.code || eid).join(" ");
    lines.push([r.id, typeLabel, (r.indicators || []).join(" "), r.text, evidence, r.closureState || "不适用"].map(csvCell).join(","));
  });
  return "\uFEFF" + lines.join("\n");
}
export function buildProjectListCsv(projects) {
  const lines = ["项目编号,项目名称,受审组织,产品,范围,状态,进度"];
  (projects || []).forEach(p => lines.push([p.id, p.name, p.organization, p.product, (p.processes || []).join(" "), STATUS_LABEL[p.status] || p.status, `${p.progress || 0}%`].map(csvCell).join(",")));
  return "\uFEFF" + lines.join("\n");
}
export function buildElementsCsv() {
  const lines = ["过程,实践,名称,审核意图"];
  PROCESS_CATALOG.flatMap(p => (PRACTICE_LIBRARY[p.id] || []).map(x => [p.id, ...x])).forEach(r => lines.push(r.map(csvCell).join(",")));
  return "\uFEFF" + lines.join("\n");
}
export function buildCustomAuditCsv(project) {
  const lines = ["编号,问题,评分,结论与理由,发现,证据"];
  (project.assessments || []).forEach(a => {
    const findings = (a.findings || []).map(f => `${f.type} ${f.text}`).join("；");
    lines.push([a.code, a.title, a.rating, a.reason, findings, (a.refs || []).join("；")].map(csvCell).join(","));
  });
  return "\uFEFF" + lines.join("\n");
}

// ---------------------------------------------------------------------------
// LLM provider integration (backend only; API key never leaves the machine)
// ---------------------------------------------------------------------------
export const indicatorAssessmentSchema = {
  type: "object",
  additionalProperties: false,
  required: ["assessments"],
  properties: {
    assessments: {
      type: "array",
      maxItems: 8,
      items: {
        type: "object",
        additionalProperties: false,
        required: ["process", "code", "rating", "confidence", "reason", "findings", "evidenceAnalysis", "crossProcessAnalysis", "scoreBreakdown", "interviewQuestions", "closureEvidence"],
        properties: {
          process: { type: "string" },
          code: { type: "string" },
          rating: { type: "string", enum: ["N", "P-", "P", "P+", "L-", "L", "L+", "F"] },
          confidence: { type: "integer", minimum: 0, maximum: 100 },
          reason: { type: "string" },
          findings: { type: "array", maxItems: 6, items: { type: "object", additionalProperties: false, required: ["type", "text"], properties: { type: { type: "string", enum: ["O", "W", "R"] }, text: { type: "string" } } } },
          evidenceAnalysis: { type: "array", maxItems: 3, items: { type: "object", additionalProperties: false, required: ["evidenceCode", "claim", "locator", "excerpt", "strength"], properties: { evidenceCode: { type: "string" }, claim: { type: "string" }, locator: { type: "string" }, excerpt: { type: "string" }, strength: { type: "string", enum: ["direct", "corroborating", "index-only"] } } } },
          crossProcessAnalysis: { type: "array", maxItems: 8, items: { type: "object", additionalProperties: false, required: ["sourceProcess", "targetProcess", "relationType", "scopeStatus", "analysisPasses", "evidenceCodes", "supportedClaim", "gapOrRisk", "followUp"], properties: {
            sourceProcess: { type: "string" }, targetProcess: { type: "string" }, relationType: { type: "string" }, scopeStatus: { type: "string", enum: ["in-scope", "related-only"] },
            analysisPasses: { type: "array", maxItems: 4, items: { type: "string", enum: ["qualified-flow", "agree-summarize", "divide-control", "trace-consistency"] } },
            evidenceCodes: { type: "array", maxItems: 5, items: { type: "string" } }, supportedClaim: { type: "string" }, gapOrRisk: { type: "string" }, followUp: { type: "string" }
          } } },
          scoreBreakdown: { type: "object", additionalProperties: false, required: ["definition", "implementation", "consistency", "governance", "closure"], properties: { definition: { type: "integer", minimum: 0, maximum: 100 }, implementation: { type: "integer", minimum: 0, maximum: 100 }, consistency: { type: "integer", minimum: 0, maximum: 100 }, governance: { type: "integer", minimum: 0, maximum: 100 }, closure: { type: "integer", minimum: 0, maximum: 100 } } },
          interviewQuestions: { type: "array", maxItems: 4, items: { type: "string" } },
          closureEvidence: { type: "array", maxItems: 4, items: { type: "string" } }
        }
      }
    }
  }
};

function responsesEndpoint(baseUrl) {
  const parsed = new URL(baseUrl);
  if (!["http:", "https:"].includes(parsed.protocol)) throw new Error("Base URL must use HTTP(S)");
  return parsed.pathname.endsWith("/responses") ? parsed.toString() : `${parsed.toString().replace(/\/$/, "")}/responses`;
}
export function extractOutputText(payload) {
  if (typeof payload.output_text === "string") return payload.output_text;
  const parts = [];
  for (const item of payload.output || []) {
    for (const content of item.content || []) {
      if (typeof content.text === "string") parts.push(content.text);
    }
  }
  return parts.join("\n").trim();
}
function parseJsonOutput(text) {
  const cleaned = String(text || "").trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  try { return JSON.parse(cleaned); } catch (_) {
    const start = cleaned.indexOf("{");
    const end = cleaned.lastIndexOf("}");
    if (start >= 0 && end > start) return JSON.parse(cleaned.slice(start, end + 1));
    throw new Error("Provider returned invalid JSON");
  }
}
export async function callProvider(config, requestBody, timeoutMs = 90000) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  const headers = { "content-type": "application/json" };
  const key = config?.apiKey || process.env.AUDITFLOW_CODEX_API_KEY || process.env.OPENAI_API_KEY;
  if (key) headers.authorization = `Bearer ${key}`;
  try {
    const providerResponse = await fetch(responsesEndpoint(config.baseUrl), { method: "POST", headers, body: JSON.stringify(requestBody), signal: controller.signal });
    const payload = await providerResponse.json().catch(() => ({}));
    return { ok: providerResponse.ok, status: providerResponse.status, payload };
  } finally { clearTimeout(timeout); }
}
export function buildIndicatorPrompt(project, evidence, indicators, language = "zh-CN") {
 const evidenceCodes = (evidence || []).map(item => item.code).filter(Boolean);
  if (language === "en") {
    return `You are a lead Automotive SPICE PAM 4.0 assessor. Review each BP/GP candidate and return strict JSON only. Every natural-language field in the response must be English; do not output Chinese.

Non-negotiable guardrails:
1. Cite only Evidence Codes supplied in the input. Do not invent documents, sections, interviews, or execution facts.
2. Distinguish process definition, project execution, cross-sample consistency, configuration control, and closure. File names or metadata are index-only evidence.
3. Only locatable content from the target process may be direct evidence. Evidence from upstream/downstream processes, MAN.3, SUP.1, SUP.8, SUP.9, or SUP.10 is corroborating only and cannot replace direct evidence.
4. With no direct or corroborating evidence rate N. Metadata-only evidence cannot exceed P+. One direct item cannot exceed L-. F requires multiple direct sources proving stable closure across cycles.
5. For every indicator, run qualified-flow, agree-summarize, divide-control, and trace-consistency analysis. Related processes outside formal scope are observations only and must use scopeStatus=related-only.
6. Helix evidence must cite the supplied sheet, table, row, and field locator. ID, status, owner, version/baseline, relationships, impact, and closure fields must be considered together.
7. Explain what was read, the relationship analysed, what it supports, what remains unproven, the rating effect, interview questions, and the minimum closure evidence. O is fact, W is a criterion gap, and R is an actionable verifiable recommendation. Do not claim formal certification.

Allowed Evidence Codes: ${evidenceCodes.join(", ") || "none"}

Project, relation model, evidence, and indicator input:
${JSON.stringify({ project: project, relationModel: { workflow: REVIEW_WORKFLOW, analysisPasses: CROSS_PROCESS_PASSES, formalScope: project.processes || [], supportProcesses: SUPPORT_PROCESS_RELATIONS.map(item => item[0]), helixFieldGroups: HELIX_FIELD_GROUPS.map(([key, label]) => ({ key, label })) }, evidence, indicators })}`;
  }
  return `你是一名具备 Automotive SPICE PAM 4.0 经验的主任评估师。请逐项复核 BP/GP 的候选评分，并输出严格 JSON。\n\n不可违反的护栏：\n1. 只能引用输入中存在的 Evidence Code，不得编造文件、章节、访谈或执行事实。\n2. 区分流程定义、项目实施、跨样本一致性、受控状态和问题闭环；文件名或元数据只能算 index-only。\n3. 只有目标过程自身、可定位且直接证明指标的内容才能算 direct；上游、下游、MAN.3、SUP.1、SUP.8、SUP.9、SUP.10 的证据默认只能算 corroborating，不能替代目标过程直接证据。\n4. 无直接或间接证据必须评 N；仅元数据不得超过 P+；只有一条直接证据不得超过 L-；达到 F 必须有多来源直接证据且证明跨周期稳定闭环。\n5. 对每个指标执行四遍跨过程分析：(a) qualified-flow 合格输入到合格输出；(b) agree-summarize 约定及汇总沟通；(c) divide-control 分解、委派、集成与控制；(d) trace-consistency 双向追溯、语义一致、影响分析和覆盖完整性。\n6. 对正式范围内过程输出 BP/GP 候选评分；范围外关联过程只输出 scopeStatus=related-only 的非评级观察。\n7. SUP.9 的问题应检查是否触发 SUP.10 变更并双向追溯；SUP.10 应追踪所有受影响工作产品和相关问题；SUP.8 的配置状态应支持 MAN.3 进展与发布基线；MAN.3 应检查全部工程和支撑过程的接口、承诺、计划一致性与纠正措施。\n8. 对 Helix 表格必须使用给定的 Sheet/Slide/Page、表名、行号和字段名定位；ID、状态、责任、版本/基线、上下游关系、影响/关闭字段需联合判断。仅存在链接值不能证明关系语义正确，仅存在 Closed 状态不能证明验证与授权关闭。\n9. 每项理由需说明读了什么证据、沿哪条关系分析、支持了什么、仍未证明什么、为什么影响或不影响正式评分，以及最小关闭证据。\n10. O 是客观事实，W 是对标准判据的差距，R 是可执行且可验证的建议。AI 只给候选结论，不宣称正式认证。\n\n允许引用的 Evidence Code：${evidenceCodes.join(", ") || "无"}\n\n项目、关系模型和逐项输入：\n${JSON.stringify({ project: project, relationModel: { workflow: REVIEW_WORKFLOW, analysisPasses: CROSS_PROCESS_PASSES, formalScope: project.processes || [], supportProcesses: SUPPORT_PROCESS_RELATIONS.map(item => item[0]), helixFieldGroups: HELIX_FIELD_GROUPS.map(([key, label]) => ({ key, label })) }, evidence, indicators })}`;
}
export function buildIndicatorRequest(config, project, evidence, indicators, language = "zh-CN") {
  const languageInstruction = language === "en" ? "Output every natural-language field in English only. Do not use Chinese in the response." : "";
  return {
    model: config.model,
    input: `${languageInstruction}\n\n${buildIndicatorPrompt(project, evidence, indicators, language)}`,
    store: false,
    text: { format: { type: "json_schema", name: "aspice_indicator_assessments", strict: true, schema: indicatorAssessmentSchema } }
  };
}
function buildEnglishOpinionPrompt(project, type, assessment = null) {
  if (assessment) {
    return `You are a lead Automotive SPICE 4.0 assessor. Provide a concise, actionable, and auditable opinion in English only for this BP/GP. Distinguish direct, corroborating, and index-only evidence; do not rate related processes outside formal scope. Explain evidence, relationships, unproven points, rating effect, interview questions, and minimum closure evidence.
${JSON.stringify({ project: { id: project.id, scope: project.processes, targetLevel: project.targetLevel }, coverage: traceCoverage(project), assessment: { indicator: indicatorKey(assessment), criterion: assessment.criterion, rating: assessment.rating, aiCandidate: assessment.aiCandidateRating, evidence: assessment.evidenceAnalysis, crossProcess: assessment.crossProcessAnalysis, missing: assessment.evidenceSufficiency?.missingTypes } })}`;
  }
  const evidenceContext = (project.evidence || []).slice(0, 8).map(e => {
    const source = [e.source || "local", e.scope || "formal scope", e.structure || "metadata"].join(", ");
    const helix = e.helix?.detected ? ", Helix " + e.helix.score + "% / " + e.helix.rowCount + " rows" : "";
    const excerpt = e.content ? String(e.content).slice(0, 420) : tablesToEvidenceText(e.tables || []).slice(0, 420);
    return "- " + e.name + " (" + source + helix + ")" + (excerpt ? ": " + excerpt : "");
  }).join("\n");
  const resultContext = (project.assessments || []).filter(a => RATING_SCORE[a.rating] < 85).slice(0, 20).map(a => "- " + a.code + " " + a.title + ": " + a.rating + "; " + a.reason).join("\n");
  return `You are a senior automotive process assessor. Based on the audit scope, evidence index, and deterministic rule-engine result below, write a 120–220 word management opinion in English only. Distinguish process definition from project execution evidence; state the capability gate, highest-priority risk, and minimum closure evidence. Do not claim formal certification.

Audit type: ${type}
Project: ${project.name}
Formal scope: ${project.processes?.join(", ") || project.level || "custom audit"}
Evidence:
${evidenceContext || "- no extractable text"}
Candidate ratings:
${resultContext || "- no P/L weaknesses at present"}`;
}

export function buildOpinionPrompt(project, type, assessment = null, language = "zh-CN") {
  if (language === "en") return buildEnglishOpinionPrompt(project, type, assessment);
  if (assessment) {
    return `你是一名 Automotive SPICE 4.0 主任评估师。请针对以下单个 BP/GP 给出简洁、可执行、可复核的中文意见。必须区分 direct、corroborating、index-only；范围外过程不评级；说明证据、关系、未证明事项、评分影响、访谈问题和最小关闭证据。\n${JSON.stringify({ project: { id: project.id, scope: project.processes, targetLevel: project.targetLevel }, coverage: traceCoverage(project), assessment: { indicator: indicatorKey(assessment), criterion: assessment.criterion, rating: assessment.rating, aiCandidate: assessment.aiCandidateRating, evidence: assessment.evidenceAnalysis, crossProcess: assessment.crossProcessAnalysis, missing: assessment.evidenceSufficiency?.missingTypes } })}`;
  }
  const evidenceContext = (project.evidence || []).slice(0, 8).map(e => `- ${e.name}（${e.source || "本地"}，${e.scope || "全部"}，${e.structure || "元数据"}${e.helix?.detected ? `，Helix ${e.helix.score}% / ${e.helix.rowCount} 行` : ""}）${e.content ? `：${e.content.slice(0, 420)}` : tablesToEvidenceText(e.tables || []).slice(0, 420)}`).join("\n");
  const resultContext = (project.assessments || []).filter(a => RATING_SCORE[a.rating] < 85).slice(0, 20).map(a => `- ${a.code} ${a.title}: ${a.rating}; ${a.reason}`).join("\n");
  return `你是一名资深汽车行业过程审核员。请根据以下审核范围、证据索引和固定规则引擎结果，用中文给出一段 120–220 字的管理层专业意见。必须区分过程定义和项目执行证据；指出等级门槛、最高优先级风险和最小关闭证据；不得宣称正式认证。\n\n审核类型：${type}\n项目：${project.name}\n范围：${project.processes?.join("、") || project.level || "自定义方案"}\n证据：\n${evidenceContext || "- 尚无可提取文本"}\n评分候选：\n${resultContext || "- 当前没有 P/L 弱项"}`;
}
export function buildEvidenceContextForBatch(project, batch) {
  return (project.evidence || []).filter(e => batch.some(a => evidenceAppliesTo(e, a.process, project.processes || []))).slice(0, 16).map(e => ({
    id: e.id,
    code: e.code,
    name: e.name,
    scope: e.scope,
    primaryProcesses: inferEvidencePrimaryProcesses(e, project.processes || []),
    source: e.source,
    structure: e.structure,
    helix: e.helix,
    locators: (e.locators || []).slice(0, 6),
    content: String(e.content || tablesToEvidenceText(e.tables || [])).slice(0, 5000),
    tableDigest: (e.tables || []).slice(0, 6).map(table => ({ source: table.source, name: table.name, headers: table.headers, rowCount: table.rowCount, rows: table.rows.slice(0, 8), helix: table.helix }))
  }));
}

// Keep an auditable, compact project context next to the uploaded excerpts.
// This gives Codex the linked evidence, open gaps and version direction
// needed for specific, verifiable improvement recommendations.
export function buildCodexProjectContext(project) {
  const openRecords = (project.records || []).filter(record => record.type === "weakness" || record.closureState === "Open").slice(0, 40).map(record => ({
    id: record.id,
    type: record.type,
    status: record.status,
    closureState: record.closureState,
    indicators: record.indicators || [],
    evidenceIds: record.evidenceIds || [],
    text: String(record.text || "").slice(0, 900)
  }));
  const versions = (project.runs || []).slice(0, 5).map(run => ({
    id: run.id,
    version: run.version,
    date: run.date,
    summary: run.summary,
    overallRating: averageRating(run.assessments || []),
    weakIndicators: (run.assessments || []).filter(item => (RATING_SCORE[item.rating] || 0) < 50).map(item => String(item.process || "") + " " + String(item.code || "")).slice(0, 30)
  }));
  return {
    formalScope: project.processes || [],
    traceability: traceCoverage(project),
    assessmentQuality: assessmentQuality(project),
    openRecords,
    versions,
    linkedEvidence: (project.traceLinks || []).slice(0, 80).map(link => ({ indicator: link.indicator, evidenceId: link.evidenceId, evidenceCode: link.evidenceCode, confirmed: !!link.confirmed, strength: link.strength })),
    improvementInstruction: "Recommendations must name the affected BP/GP, the specific uploaded or linked evidence to update, the owner/closure evidence to obtain, and a verifiable completion criterion."
  };
}

export function mergeIndicatorResults(project, results) {
  let updated = 0;
  (results || []).forEach(result => {
    const target = project.assessments.find(a => a.process === result.process && canonicalCode(a.code) === canonicalCode(result.code));
    if (!target) return;
    const allowedEvidence = new Set((target.evidenceAnalysis || []).map(e => e.evidenceCode));
    const cited = (result.evidenceAnalysis || []).filter(e => allowedEvidence.has(e.evidenceCode));
    const requestedRating = RATING_ORDER.includes(result.rating) ? result.rating : target.rating;
    target.aiCandidateRating = ratingCappedByEvidence(requestedRating, target.evidenceSufficiency);
    if (!target.reviewed) target.rating = target.aiCandidateRating;
    target.achievementPercent = RATING_SCORE[target.rating];
    target.confidence = Math.max(40, Math.min(98, Number(result.confidence) || target.confidence));
    target.reason = String(result.reason || target.reason).trim();
    target.findings = Array.isArray(result.findings) && result.findings.length ? result.findings.filter(f => ["O", "W", "R"].includes(f.type) && f.text).slice(0, 6) : target.findings;
    target.interviewQuestions = Array.isArray(result.interviewQuestions) && result.interviewQuestions.length ? result.interviewQuestions.slice(0, 4) : target.interviewQuestions;
    target.closureEvidence = Array.isArray(result.closureEvidence) && result.closureEvidence.length ? result.closureEvidence.slice(0, 4) : target.closureEvidence;
    target.scoreBreakdown = result.scoreBreakdown && typeof result.scoreBreakdown === "object" ? Object.fromEntries(Object.entries(result.scoreBreakdown).map(([k, v]) => [k, clampScore(v)])) : target.scoreBreakdown;
    if (cited.length) target.evidenceAnalysis = target.evidenceAnalysis.map(local => ({ ...local, ...cited.find(x => x.evidenceCode === local.evidenceCode) }));
    if (Array.isArray(result.crossProcessAnalysis) && result.crossProcessAnalysis.length) {
      const allowed = new Set((target.crossProcessAnalysis || []).map(row => `${row.sourceProcess}|${row.targetProcess}|${row.relationType}`));
      target.crossProcessAnalysis = result.crossProcessAnalysis.filter(row => allowed.has(`${row.sourceProcess}|${row.targetProcess}|${row.relationType}`)).slice(0, 8);
    }
    target.aiSource = "provider-structured-output";
    updated++;
  });
  return updated;
}

export async function enrichProjectWithLLM(project, type, config, options = {}) {
  const result = { used: false, opinion: false, assessments: 0, error: "" };
  const language = options.language === "en" ? "en" : "zh-CN";
  const codexProjectContext = buildCodexProjectContext(project);
  if (!config?.enabled || config.mode !== "provider" || !config.baseUrl || !config.model) {
    result.error = "AI provider is not enabled in backend-config.json";
    return result;
  }
  if (!config.apiKey) {
    result.error = "API key is not configured (backend-config.json ai.apiKey or OPENAI_API_KEY)";
    return result;
  }
  result.used = true;
  if (type === "standard" && (project.assessments || []).length) {
    const batches = [];
    for (let index = 0; index < project.assessments.length; index += 8) batches.push(project.assessments.slice(index, index + 8));
    for (const batch of batches) {
      try {
        const evidence = buildEvidenceContextForBatch(project, batch);
        const indicators = batch.map(a => ({ process: a.process, kind: a.kind, pa: a.pa, code: a.code, title: a.title, criterion: a.criterion, localRating: a.rating, localReason: a.reason, requiredEvidence: a.requiredEvidence, evidenceAnalysis: a.evidenceAnalysis, evidenceSufficiency: a.evidenceSufficiency, crossProcessAnalysis: a.crossProcessAnalysis }));
        const requestBody = buildIndicatorRequest(config, { name: project.name, organization: project.organization, product: project.product, pam: project.pam, targetLevel: project.targetLevel, processes: project.processes || [], projectContext: codexProjectContext }, evidence, indicators, language);
        let providerResult = await callProvider(config, requestBody);
        if (!providerResult.ok) {
          const jsonOnly = language === "en" ? "Return only the requested JSON object. Do not use Markdown or Chinese." : "只返回符合指定结构的 JSON 对象，不要 Markdown。";
          providerResult = await callProvider(config, { model: config.model, input: `${buildIndicatorPrompt({ name: project.name, organization: project.organization, product: project.product, pam: project.pam, targetLevel: project.targetLevel, processes: project.processes || [], projectContext: codexProjectContext }, evidence, indicators, language)}\n\n${jsonOnly}`, store: false });
        }
        if (!providerResult.ok) throw new Error(providerResult.payload?.error?.message || `Provider returned ${providerResult.status}`);
        const output = extractOutputText(providerResult.payload);
        if (!output) throw new Error("Provider returned no output");
        const parsed = parseJsonOutput(output);
        if (!Array.isArray(parsed.assessments)) throw new Error("Provider JSON does not include assessments");
        result.assessments += mergeIndicatorResults(project, parsed.assessments);
      } catch (error) {
        result.error = error.message || String(error);
        break;
      }
    }
  }
  if (type === "standard") {
    try {
      const prompt = buildOpinionPrompt(project, type, null, language);
      const providerResult = await callProvider(config, { model: config.model, input: prompt, store: false }, 45000);
      if (providerResult.ok) {
        const output = extractOutputText(providerResult.payload);
        if (output) { project.aiOpinion = output.trim(); result.opinion = true; }
      } else if (!result.error) {
        result.error = providerResult.payload?.error?.message || `Provider returned ${providerResult.status}`;
      }
    } catch (error) {
      if (!result.error) result.error = error.message || String(error);
    }
  }
  refreshProjectOutcome(project);
  return result;
}

// ---------------------------------------------------------------------------
// Full evaluation pipeline
// ---------------------------------------------------------------------------
export async function evaluateProject(project, type = "standard", scheme = null, config = null, options = {}) {
  const input = deepCopy(project || {});
  initializeProjectModel(input);
  if (type === "standard") {
    input.assessments = buildAssessments(input.processes || [], input.runs?.length || 0, input.evidence || []);
  } else {
    input.assessments = buildCustomAssessments(input, scheme);
  }
  input.status = "review";
  input.progress = Math.max(input.progress || 0, 72);
  refreshProjectOutcome(input);
  const llm = await enrichProjectWithLLM(input, type, config, options);
  return { project: input, engine: ENGINE_NAME, version: VERSION, llm };
}

// ---------------------------------------------------------------------------
// Config / file output helpers
// ---------------------------------------------------------------------------
export function loadAIConfig(filePath = path.join(currentDir, "backend-config.json")) {
  let fileConfig = {};
  try {
    if (existsSync(filePath)) fileConfig = JSON.parse(readFileSync(filePath, "utf8"));
  } catch (_) { /* fall back to defaults */ }
  const ai = fileConfig.ai || {};
  return {
    // v6.6: model review is opt-in. No key, no accidental out-of-domain
    // evidence transfer; the local rule engine remains the default.
    enabled: ai.enabled === true,
    mode: ai.mode || "provider",
    baseUrl: ai.baseUrl || process.env.OPENAI_BASE_URL || "https://llmcost.johnsonelectric.com/v1",
    model: ai.model || process.env.OPENAI_MODEL || "gpt-5.4",
    apiKey: ai.apiKey || process.env.AUDITFLOW_CODEX_API_KEY || process.env.OPENAI_API_KEY || "",
    outputDir: fileConfig.outputDir || "output",
    port: Number(fileConfig.port || process.env.AUDITFLOW_PORT || 4173)
  };
}
export function safeFilename(value) {
  return String(value || "auditflow").replace(/[^a-zA-Z0-9._-]/g, "-").replace(/-+/g, "-").slice(0, 80);
}
export function ensureOutputDir(dir) {
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
  return dir;
}
export function writeOutput(dir, filename, content, encoding = "utf8") {
  ensureOutputDir(dir);
  const full = path.join(dir, filename);
  writeFileSync(full, content, encoding);
  return full;
}
export function reportMeta(project, format, ext) {
  const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const base = safeFilename(`${project.id || project.name || "project"}-${format}-${stamp}`);
  return { base, filename: `${base}.${ext}` };
}
