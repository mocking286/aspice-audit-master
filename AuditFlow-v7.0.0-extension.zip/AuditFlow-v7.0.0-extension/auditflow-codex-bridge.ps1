param(
  [int]$Port = 4173
)

$ErrorActionPreference = "Stop"
$bridgeRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$serverFile = Join-Path $bridgeRoot "server.mjs"

if (-not (Test-Path -LiteralPath $serverFile)) {
  throw "AuditFlow local service was not found next to this script."
}

$nodeCommand = Get-Command node -ErrorAction SilentlyContinue
if (-not $nodeCommand) {
  throw "Node.js is required for the local Codex bridge. Install Node.js, then run this script again."
}

$env:AUDITFLOW_PORT = [string]$Port
Write-Host "AuditFlow Codex bridge is starting on http://127.0.0.1:$Port"
Write-Host "The bridge detects local Codex/VS Code configuration without reading or displaying credentials."
& $nodeCommand.Source $serverFile
